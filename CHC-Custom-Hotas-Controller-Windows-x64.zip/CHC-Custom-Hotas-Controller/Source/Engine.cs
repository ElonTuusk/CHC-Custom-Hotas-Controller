using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace StickShift {
    public class OutputFrame {
        public Dictionary<string,double> Axes = new Dictionary<string,double>();
        public Dictionary<string,bool> Buttons = new Dictionary<string,bool>();
        public Dictionary<string,int> Hats = new Dictionary<string,int>();
        public HashSet<int> Keys = new HashSet<int>();
        public string NextMode;
    }
    class ActionState {
        public bool Previous,Latched;
        public List<MacroStep> Steps;
        public int Step,Repetition;
        public double Deadline;
    }
    public class RuntimeCore {
        readonly List<Mapping> mappings;
        readonly Dictionary<string,ActionState> states = new Dictionary<string,ActionState>();
        public RuntimeCore(List<Mapping> maps,Dictionary<string,DeviceSample> samples) {
            mappings=maps;
            foreach(var m in maps) states[m.Id]=new ActionState { Previous = Pressed(m,Value(samples,m.Input),false) };
        }
        static bool Pressed(Mapping m,double value,bool wasPressed) {
            if(m.Input.Kind!="Axis") return value>0;
            double margin=wasPressed?.025:0;
            return value>=m.RangeMin-margin && value<=m.RangeMax+margin;
        }
        public static double Value(Dictionary<string,DeviceSample> samples,InputRef i) {
            DeviceSample s;
            if(i==null || !samples.TryGetValue(i.Device,out s) || !s.Connected) return i!=null && i.Kind=="Hat" && i.Direction<0 ? -1 : 0;
            return s.Value(i);
        }
        public OutputFrame Tick(Dictionary<string,DeviceSample> samples,double now) {
            var f=new OutputFrame();
            foreach(var m in mappings) {
                var st=states[m.Id];
                double value=Value(samples,m.Input);
                bool allowed=m.Condition==null || Value(samples,m.Condition)>0;
                bool pressed=Pressed(m,value,st.Previous);
                bool rising=pressed && !st.Previous;
                st.Previous=pressed;
                if(!allowed) { st.Latched=false;st.Steps=null; }
                string target=m.VJoy+"/"+m.Target;
                if(m.Action=="Virtual axis") {
                    if(m.Second!=null) value=AxisMath.Combine(value,Value(samples,m.Second),m.Merge);
                    f.Axes[target]=allowed?AxisMath.Apply(value,m):m.Unipolar?-1:0; continue;
                }
                if(m.Action=="Virtual hat") { f.Hats[target]=allowed?(int)value:-1;continue; }
                if(allowed && rising && m.Toggle) st.Latched=!st.Latched;
                bool active=allowed && (m.Toggle?st.Latched:pressed);
                if(m.Action=="Virtual button") { bool old;f.Buttons.TryGetValue(target,out old);f.Buttons[target]=old||active; }
                else if(m.Action=="Keyboard") { if(active) f.Keys.UnionWith(KeyNames.Parse(m.Keys)); }
                else if(m.Action=="Mouse button") { if(active) f.Keys.Add(-1-m.Target); }
                else if(m.Action=="Switch mode") { if(allowed && rising) f.NextMode=m.SwitchMode; }
                else if(m.Action=="Macro") {
                    if(allowed && rising && st.Steps==null) { st.Steps=MacroStep.Parse(m.Macro);st.Step=0;st.Repetition=0;st.Deadline=now+st.Steps[0].Duration; }
                    if(st.Steps!=null) {
                        if(now>=st.Deadline) {
                            st.Step++;
                            if(st.Step==st.Steps.Count) { st.Step=0;st.Repetition++;if(st.Repetition>=m.Repeat) st.Steps=null; }
                            if(st.Steps!=null) st.Deadline=now+st.Steps[st.Step].Duration;
                        }
                        if(st.Steps!=null) f.Keys.UnionWith(st.Steps[st.Step].Keys);
                    }
                }
            }
            return f;
        }
    }
    public class Engine : IDisposable {
        public readonly object Gate = new object();
        public readonly DeviceHub Hub = new DeviceHub();
        public readonly VirtualOutput VJoy = new VirtualOutput();
        readonly SystemOutput system = new SystemOutput();
        readonly Thread thread;
        volatile bool quit;
        public Dictionary<string,DeviceSample> Samples = new Dictionary<string,DeviceSample>();
        public bool Active,Demo;
        public string Mode="Base",Status="Stopped. Your controls are not being remapped.";
        Profile profile;
        RuntimeCore core;
        readonly Stopwatch time=Stopwatch.StartNew();
        public Engine() { thread=new Thread(Loop) { IsBackground=true,Name="StickShift input" };thread.Start(); }
        public void Scan(IntPtr handle) { lock(Gate) { Stop();Hub.Scan(handle);Samples=Hub.Read();Status=Hub.Errors.Count>0?String.Join("\n",Hub.Errors):Hub.Devices.Count+" physical device(s) connected."; } }
        public void SetDemo(bool demo) { lock(Gate) { Stop();Demo=demo;Samples=demo?DemoData.Samples(0):Hub.Read();Status=demo?"Demo preview — simulated controls. No keyboard, mouse, or vJoy output.":"Stopped. Your controls are not being remapped."; } }
        public void Start(Profile p,string mode) {
            lock(Gate) {
                Stop();p.Validate();
                if(p.Mappings.Count==0) throw new InvalidOperationException("Add a mapping before starting.");
                profile=p.Clone();Mode=mode;
                foreach(var m in profile.Mappings.Where(x=>x.Enabled)) {
                    foreach(var i in new[]{m.Input,m.Second,m.Condition}.Where(x=>x!=null)) {
                        if(Demo) { if(i.Device!=DemoData.Id) throw new InvalidOperationException("Demo can only run the simulated controller."); }
                        else if(!Hub.Supports(i)) throw new InvalidOperationException("Connect "+i.DeviceName+" and click Refresh devices. Missing input: "+i);
                    }
                }
                foreach(var mo in p.Modes) {
                    var duplicates=p.Effective(mo).Where(x=>x.Action=="Virtual axis" || x.Action=="Virtual hat").GroupBy(x=>x.Action+"/"+x.VJoy+"/"+x.Target).FirstOrDefault(x=>x.Count()>1);
                    if(duplicates!=null) throw new InvalidOperationException("Two mappings write to the same axis or hat in mode "+mo+". Use Merge for two source axes.");
                }
                if(!Demo) VJoy.Start(profile.Mappings);
                core=new RuntimeCore(profile.Effective(mode),Samples);Active=true;Status=Demo?"Demo running — no output sent.":"Mappings active. Ctrl + Alt + F12 stops all output.";
            }
        }
        public void ChangeMode(string mode) {
            lock(Gate) {
                if(!Active) { Mode=mode;return; }
                if(!profile.Modes.Contains(mode)) return;
                system.Release();if(!Demo) VJoy.Neutral();Mode=mode;core=new RuntimeCore(profile.Effective(mode),Samples);
            }
        }
        public void Stop() {
            lock(Gate) {
                Active=false;core=null;system.Release();
                try { VJoy.Stop(); } catch(Exception e) { Status="Stopped: "+e.Message;return; }
                Status=Demo?"Demo preview — no output sent.":"Stopped. Your controls are not being remapped.";
            }
        }
        void Loop() {
            while(!quit) {
                lock(Gate) {
                    try {
                        Samples=Demo?DemoData.Samples(time.Elapsed.TotalSeconds):Hub.Read();
                        if(Active) {
                            foreach(var m in profile.Effective(Mode)) foreach(var i in new[]{m.Input,m.Second,m.Condition}.Where(x=>x!=null)) {
                                DeviceSample s;if(!Samples.TryGetValue(i.Device,out s)||!s.Connected) throw new IOException(i.DeviceName+" disconnected. Reconnect, refresh devices, and start again.");
                            }
                            var f=core.Tick(Samples,time.Elapsed.TotalMilliseconds);
                            if(f.NextMode!=null && f.NextMode!=Mode) ChangeMode(f.NextMode);
                            else if(!Demo) {
                                foreach(var a in f.Axes) { var k=a.Key.Split('/');VJoy.Axis(Int32.Parse(k[0]),Int32.Parse(k[1]),a.Value); }
                                foreach(var b in f.Buttons) { var k=b.Key.Split('/');VJoy.Button(Int32.Parse(k[0]),Int32.Parse(k[1]),b.Value); }
                                foreach(var h in f.Hats) { var k=h.Key.Split('/');VJoy.Hat(Int32.Parse(k[0]),Int32.Parse(k[1]),h.Value); }
                                system.Set(f.Keys);
                            }
                        }
                    } catch(Exception e) { Stop();Status="Stopped: "+e.Message; }
                }
                Thread.Sleep(8);
            }
        }
        public void Dispose() { quit=true;thread.Join(3000);lock(Gate){Stop();Hub.Dispose();} }
    }
    public static class DemoData {
        public const string Id="00000000-0000-0000-0000-000000000001";
        public static InputRef Ref(string kind,int index,int direction=-1) { return new InputRef{Device=Id,DeviceName="Demo flight controller",Kind=kind,Index=index,Direction=direction}; }
        public static List<InputRef> Inputs() {
            var list=new List<InputRef>();for(int i=0;i<8;i++)list.Add(Ref("Axis",i));for(int i=0;i<12;i++)list.Add(Ref("Button",i));
            list.Add(Ref("Hat",0));for(int i=0;i<8;i++)list.Add(Ref("Hat",0,i));return list;
        }
        public static Dictionary<string,DeviceSample> Samples(double seconds) {
            var s=new DeviceSample{Connected=true};s.Axes[0]=Math.Sin(seconds*.6)*.76;s.Axes[1]=Math.Cos(seconds*.43)*.55;s.Axes[2]=Math.Sin(seconds*.2);
            s.Buttons[0]=(int)seconds%5==0;s.Hats[0]=(int)seconds%12<8?((int)seconds%8)*4500:-1;
            return new Dictionary<string,DeviceSample>{{Id,s}};
        }
        public static Profile Profile() {
            var p=new Profile{Name="Demo · flight essentials"};
            p.Mappings.Add(new Mapping{Input=Ref("Axis",0),Action="Virtual axis",Target=0,Label="Roll",Curve=.4});
            p.Mappings.Add(new Mapping{Input=Ref("Axis",1),Action="Virtual axis",Target=1,Label="Pitch",Curve=.3,Invert=true});
            p.Mappings.Add(new Mapping{Input=Ref("Axis",2),Action="Virtual axis",Target=2,Label="Throttle",Unipolar=true,Deadzone=0});
            p.Mappings.Add(new Mapping{Input=Ref("Button",0),Action="Virtual button",Target=0,Label="Trigger"});
            p.Mappings.Add(new Mapping{Input=Ref("Button",1),Action="Keyboard",Keys="G",Label="Landing gear"});
            p.Mappings.Add(new Mapping{Input=Ref("Button",2),Action="Macro",Label="Example sequence"});
            p.Mappings.Add(new Mapping{Input=Ref("Hat",0),Action="Virtual hat",Target=0,Label="View"});
            return p;
        }
    }
}
