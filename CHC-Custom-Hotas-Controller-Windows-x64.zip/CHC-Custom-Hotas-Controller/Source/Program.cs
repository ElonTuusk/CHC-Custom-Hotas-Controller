using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Interop;

namespace StickShift {
    public static class Program {
        [STAThread] public static int Main(string[] args) {
            string root=AppDomain.CurrentDomain.BaseDirectory;
            try {
                if(args.Contains("--self-test")){SelfTest.Run(System.IO.Path.Combine(root,"Test Results.txt"));return 0;}
                if(args.Contains("--diagnostics")){Diagnostics(root);return 0;}
                if(args.Contains("--hardware-test")){HardwareTest(root);return 0;}
                if(args.Contains("--make-starter")){MakeStarter(root);return 0;}
                if(args.Contains("--watch-inputs")){WatchInputs(root);return 0;}
                bool created;
                using(var mutex=new Mutex(true,args.Contains("--screenshot")?"Local\\StickShift.Preview":"Local\\StickShift.Desktop",out created)) {
                    if(!created){MessageBox.Show("CHC Custom Hotas Controller is already open.");return 0;}
                    var app=new Application();
                    var ui=new UserInterface(args.Contains("--screenshot"));
                    app.Run(ui.Window);
                }
                return 0;
            } catch(Exception e) {
                File.WriteAllText(System.IO.Path.Combine(root,"Error.txt"),e.ToString());
                if(args.Length==0)MessageBox.Show(e.GetBaseException().Message,"CHC Custom Hotas Controller could not start");return 1;
            }
        }
        static void WatchInputs(string root) {
            var w=new Window();var handle=new WindowInteropHelper(w).EnsureHandle();
            using(var hub=new DeviceHub())using(var log=new StreamWriter(Path.Combine(root,"Input observations.txt"),false)) {
                log.AutoFlush=true;hub.Scan(handle);var d=hub.Devices.First(x=>x.Name.IndexOf("BETAFPV",StringComparison.OrdinalIgnoreCase)>=0);
                log.WriteLine("Watching "+d.Name+" | "+DateTime.Now.ToString("HH:mm:ss"));
                var last=d.Read();foreach(var input in d.Inputs.Where(x=>x.Kind=="Axis"))log.WriteLine(input+" = "+last.Value(input).ToString("0.000"));
                var watch=System.Diagnostics.Stopwatch.StartNew();
                while(watch.Elapsed.TotalSeconds<900) {
                    var sample=d.Read();
                    foreach(var input in d.Inputs.Where(x=>x.Kind=="Axis"))if(Math.Abs(sample.Value(input)-last.Value(input))>.15){log.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff")+" | "+input+" | "+sample.Value(input).ToString("0.000"));last.Axes[input.Index]=sample.Axes[input.Index];}
                    Thread.Sleep(30);
                }
            }
            w.Close();
        }
        static void MakeStarter(string root) {
            var w=new Window();var handle=new WindowInteropHelper(w).EnsureHandle();
            using(var hub=new DeviceHub()) {
                hub.Scan(handle);var d=hub.Devices.FirstOrDefault(x=>x.Name.IndexOf("BETAFPV",StringComparison.OrdinalIgnoreCase)>=0);
                if(d==null)throw new Exception("Connect the BETAFPV controller first.");
                var p=new Profile{Name="BETAFPV · starter"};
                foreach(var input in d.Inputs.Where(x=>x.Kind=="Axis"))p.Mappings.Add(new Mapping{Input=input,Action="Virtual axis",Target=input.Index,Deadzone=0,Label="Channel "+(input.Index+1)});
                p.Save(Path.Combine(root,"Profiles","BETAFPV starter.xml"));
            }
            DemoData.Profile().Save(Path.Combine(root,"Profiles","Demo flight essentials.xml"));w.Close();
        }
        static void HardwareTest(string root) {
            var lines=new List<string>{"CHC Custom Hotas Controller vJoy loopback test",DateTime.Now.ToString("u")};
            var w=new Window();var handle=new WindowInteropHelper(w).EnsureHandle();
            var output=new VirtualOutput();
            using(var di=new SharpDX.DirectInput.DirectInput()) {
                var info=di.GetDevices(SharpDX.DirectInput.DeviceClass.GameControl,SharpDX.DirectInput.DeviceEnumerationFlags.AttachedOnly).First(x=>x.InstanceName.IndexOf("vJoy",StringComparison.OrdinalIgnoreCase)>=0);
                using(var reader=new InputDevice(di,info,handle)) {
                    var maps=new List<Mapping>();for(int i=0;i<8;i++)maps.Add(new Mapping{Input=DemoData.Ref("Axis",i),Action="Virtual axis",Target=i});
                    maps.Add(new Mapping{Input=DemoData.Ref("Button",0),Action="Virtual button"});
                    try {
                        output.Start(maps);
                        for(int i=0;i<8;i++) {
                            foreach(double value in new[]{-.6,.6}) {
                                output.Axis(1,i,value);Thread.Sleep(40);var s=reader.Read();
                                if(!s.Connected || Math.Abs(s.Axes[i]-value)>.015)throw new Exception("Axis "+i+" loopback mismatch: expected "+value+", read "+s.Axes[i]);
                            }
                            output.Axis(1,i,0);lines.Add("PASS  vJoy "+InputRef.AxisNames[i]+" positive and negative output");
                        }
                        output.Button(1,0,true);Thread.Sleep(40);if(!reader.Read().Buttons[0])throw new Exception("Virtual button press was not observed.");
                        output.Button(1,0,false);Thread.Sleep(40);if(reader.Read().Buttons[0])throw new Exception("Virtual button release was not observed.");
                        lines.Add("PASS  vJoy button press and release");
                    } finally { output.Stop(); }
                    Thread.Sleep(40);var neutral=reader.Read();if(neutral.Buttons.Any(x=>x))throw new Exception("A virtual button remained pressed after Stop.");
                    lines.Add("PASS  Stop clears virtual buttons and releases vJoy");
                }
            }
            lines.Add("No keyboard or mouse events were sent. Physical controller movement and game bindings still require user verification.");w.Close();File.WriteAllLines(Path.Combine(root,"Hardware Test Results.txt"),lines);
        }
        static void Diagnostics(string root) {
            var lines=new List<string>{"CHC Custom Hotas Controller read-only diagnostics",DateTime.Now.ToString("u")};
            var window=new Window();IntPtr handle=new WindowInteropHelper(window).EnsureHandle();
            using(var hub=new DeviceHub()) {
                hub.Scan(handle);lines.Add("Physical controllers: "+hub.Devices.Count);
                foreach(var d in hub.Devices){lines.Add(d.Name+" | "+d.Id);var sample=d.Read();lines.Add("Read successful: "+sample.Connected);lines.Add(String.Join(", ",d.Inputs.Where(x=>x.Kind=="Axis").Select(x=>x.ToString()+"="+sample.Value(x).ToString("0.000"))));lines.Add("Buttons: "+d.Inputs.Count(x=>x.Kind=="Button")+"; hats: "+d.Inputs.Count(x=>x.Kind=="Hat"&&x.Direction<0));}
                lines.AddRange(hub.Errors);
            }
            lines.Add(new VirtualOutput().Describe());window.Close();File.WriteAllLines(System.IO.Path.Combine(root,"Device Diagnostics.txt"),lines);
        }
    }
    public static class SelfTest {
        static List<string> log=new List<string>();
        static void Assert(bool condition,string name){if(!condition)throw new Exception("FAILED: "+name);log.Add("PASS  "+name);}
        static bool Near(double a,double b){return Math.Abs(a-b)<.00001;}
        static bool Reject(Action f){try{f();return false;}catch{return true;}}
        public static void Run(string output) {
            log.Clear();
            var m=new Mapping{Deadzone=.1};
            Assert(Near(AxisMath.Apply(.05,m),0),"Dead zone suppresses noise");
            Assert(Near(AxisMath.Apply(.55,m),.5),"Dead zone rescales remaining travel");
            Assert(Near(AxisMath.Apply(-1,m),-1)&&Near(AxisMath.Apply(1,m),1),"Endpoints retain full range");
            m.Invert=true;Assert(Near(AxisMath.Apply(1,m),-1),"Axis inversion");m.Invert=false;m.Curve=.7;
            double previous=-2;bool monotonic=true;for(int i=0;i<=1000;i++){double v=AxisMath.Apply(i/500.0-1,m);if(v<previous)monotonic=false;previous=v;}
            Assert(monotonic,"Curve is monotonic");m.Unipolar=true;m.Deadzone=.1;
            Assert(Near(AxisMath.Apply(-.9,m),-1),"Throttle start dead zone");m.Invert=true;Assert(Near(AxisMath.Apply(1,m),-1),"Inverted throttle endpoint");
            Assert(Near(AxisMath.Combine(1,-1,"Difference"),1),"Differential axis merge");
            Assert(KeyNames.Parse("RCtrl+Space").SequenceEqual(new[]{163,32}),"Right modifier chord parsing");
            Assert(Reject(()=>KeyNames.Parse("Ctrl+Alt+F12")),"Emergency stop chord is reserved");
            Assert(Reject(()=>KeyNames.Parse("NotAKey")),"Invalid key is rejected");
            Assert(MacroStep.Parse("Ctrl+G\nWAIT 200\nG").Count==5,"Macro sequence parsing");
            Assert(Reject(()=>MacroStep.Parse("WAIT -1")),"Negative macro delays rejected");
            var p=DemoData.Profile();p.Validate();
            var overrideMap=new Mapping{Input=DemoData.Ref("Axis",0),Action="Virtual axis",Mode="Flight",Target=0};p.Mappings.Add(overrideMap);
            Assert(p.Effective("Flight").Count==7&&p.Effective("Flight").Contains(overrideMap),"Mode overrides replace Base mappings");overrideMap.Enabled=false;
            Assert(p.Effective("Flight").Count==6,"Disabled override blocks Base mapping");
            p.Mappings.Add(new Mapping{Input=DemoData.Ref("Axis",0),Action="Virtual button"});p.Validate();Assert(p.Effective("Base").Count==8,"One source can have multiple actions");p.Mappings.RemoveAt(p.Mappings.Count-1);
            var saved=p.Clone();Assert(saved.Mappings.Count==p.Mappings.Count&&saved.Mappings[0]!=p.Mappings[0],"Profile copies do not share editable mappings");
            string temp=Path.Combine(Path.GetDirectoryName(output),"Profiles","self-test.xml");p.Save(temp);p.Save(temp);var read=Profile.Load(temp);Assert(read.Name==p.Name&&read.Mappings.Count==p.Mappings.Count,"Atomic profile save and reload");File.Delete(temp);File.Delete(temp+".bak");
            p.Mappings[0].Curve=Double.NaN;Assert(Reject(()=>p.Validate()),"Invalid numeric profile rejected");
            var button=new Mapping{Input=DemoData.Ref("Button",0),Action="Keyboard",Keys="Ctrl+G"};var sample=DemoData.Samples(1);sample[DemoData.Id].Buttons[0]=false;
            var runtime=new RuntimeCore(new List<Mapping>{button},sample);sample[DemoData.Id].Buttons[0]=true;Assert(runtime.Tick(sample,0).Keys.SetEquals(new[]{162,71}),"Button press holds keyboard chord");sample[DemoData.Id].Buttons[0]=false;Assert(runtime.Tick(sample,10).Keys.Count==0,"Button release releases chord");
            button.Toggle=true;runtime=new RuntimeCore(new List<Mapping>{button},sample);sample[DemoData.Id].Buttons[0]=true;runtime.Tick(sample,0);sample[DemoData.Id].Buttons[0]=false;Assert(runtime.Tick(sample,10).Keys.Count==2,"Toggle survives button release");sample[DemoData.Id].Buttons[0]=true;Assert(runtime.Tick(sample,20).Keys.Count==0,"Second press clears toggle");
            button.Toggle=false;button.Condition=DemoData.Ref("Button",1);sample[DemoData.Id].Buttons[1]=false;runtime=new RuntimeCore(new List<Mapping>{button},sample);Assert(runtime.Tick(sample,0).Keys.Count==0,"Condition gates output");sample[DemoData.Id].Buttons[1]=true;Assert(runtime.Tick(sample,10).Keys.Count==2,"Held condition enables output");
            button.Condition=null;button.Action="Macro";button.Macro="G\nWAIT 100\nH";sample[DemoData.Id].Buttons[0]=false;runtime=new RuntimeCore(new List<Mapping>{button},sample);sample[DemoData.Id].Buttons[0]=true;Assert(runtime.Tick(sample,0).Keys.Contains(71),"Macro starts on press");Assert(runtime.Tick(sample,60).Keys.Count==0,"Macro releases first key");runtime.Tick(sample,120);Assert(runtime.Tick(sample,220).Keys.Contains(72),"Macro observes explicit wait");runtime.Tick(sample,280);Assert(runtime.Tick(sample,340).Keys.Count==0,"Macro completes without retriggering held input");
            runtime=new RuntimeCore(new List<Mapping>{button},sample);Assert(runtime.Tick(sample,0).Keys.Count==0,"Held input does not trigger macro on mode entry");
            var hat=DemoData.Ref("Hat",0,1);sample[DemoData.Id].Hats[0]=4500;Assert(sample[DemoData.Id].Value(hat)==1,"Diagonal hat direction");sample[DemoData.Id].Hats[0]=-1;Assert(sample[DemoData.Id].Value(hat)==0,"Neutral hat does not trigger direction");
            var a=new Mapping{Input=DemoData.Ref("Button",0),Action="Virtual button"};var b=new Mapping{Input=DemoData.Ref("Button",1),Action="Virtual button"};sample[DemoData.Id].Buttons[0]=true;sample[DemoData.Id].Buttons[1]=false;runtime=new RuntimeCore(new List<Mapping>{a,b},sample);Assert(runtime.Tick(sample,0).Buttons["1/0"],"Shared virtual button combines sources with OR");
            a.Input=DemoData.Ref("Axis",0);sample[DemoData.Id].Axes[0]=0;runtime=new RuntimeCore(new List<Mapping>{a},sample);Assert(!runtime.Tick(sample,0).Buttons["1/0"],"Axis outside activation range stays released");sample[DemoData.Id].Axes[0]=.8;Assert(runtime.Tick(sample,10).Buttons["1/0"],"Axis inside activation range presses button");sample[DemoData.Id].Axes[0]=.49;Assert(runtime.Tick(sample,20).Buttons["1/0"],"Axis range hysteresis suppresses chatter");sample[DemoData.Id].Axes[0]=.4;Assert(!runtime.Tick(sample,30).Buttons["1/0"],"Leaving axis range releases button");
            var switchInput=DemoData.Ref("Axis",4);
            var positions=new List<Mapping>{new Mapping{Input=switchInput,Target=0,RangeMin=-1,RangeMax=-.5},new Mapping{Input=switchInput,Target=1,RangeMin=-.45,RangeMax=.45},new Mapping{Input=switchInput,Target=2,RangeMin=.5,RangeMax=1}};
            var multi=new Profile{Mappings=positions};multi.Validate();Assert(multi.Effective("Base").Count==3,"All three switch actions reach the runtime");
            sample[DemoData.Id].Axes[4]=0;runtime=new RuntimeCore(multi.Effective("Base"),sample);
            foreach(int position in new[]{0,1,2,1,0}) {sample[DemoData.Id].Axes[4]=position-1;var f=runtime.Tick(sample,0);Assert(f.Buttons["1/"+position]&&f.Buttons.Values.Count(x=>x)==1,"Switch position "+position+" activates only its assigned button");}
            var inheritedAction=new Profile{Mappings=new List<Mapping>{positions[1]}}.Clone().Mappings[0];inheritedAction.Id=Guid.NewGuid().ToString();inheritedAction.Mode="Flight";inheritedAction.Target=7;multi.UpsertAction(inheritedAction,positions[1].Id);multi.Validate();
            Assert(multi.Effective("Flight").Count==3&&multi.Effective("Flight").Any(x=>x.Target==7),"Editing inherited action preserves sibling positions");
            Assert(multi.Effective("Base").Any(x=>x.Target==1),"Mode override leaves Base positions unchanged");
            var round=multi.Clone();Assert(round.Effective("Flight").Count==3,"Multiple actions survive profile serialization");
            multi.NameControl(switchInput,"SB");Assert(switchInput.ToString()=="SB"&&multi.Mappings.All(x=>x.Input.ToString()=="SB"),"Physical switch name replaces axis labels across modes");
            round=multi.Clone();var reconnected=DemoData.Ref("Axis",4);round.ApplyControlLabels(new[]{reconnected});Assert(reconnected.ToString()=="SB","Saved switch name restores after reconnect");
            var defaults=Enumerable.Range(0,8).Select(x=>new InputRef{Device=DemoData.Id,Kind="Axis",Index=x}).ToList();
            defaults.Add(new InputRef{Device=DemoData.Id,Kind="Button",Index=0});
            Assert(!ControllerNames.Configure("unknown","Unknown controller",defaults),"Unknown controller uses generic names, not a claimed recognized layout");
            new Profile().ApplyControlLabels(defaults);
            Assert(defaults.Take(4).Select(x=>x.ToString()).SequenceEqual(new[]{"Roll","Pitch","Collective","Rotor"}),"Empty profiles label all four flight axes");
            Assert(defaults.Skip(4).Select(x=>x.ToString()).SequenceEqual(new[]{"Switch 1","Switch 2","Switch 3","Switch 4","Switch 5"}),"Extra axes and physical buttons have distinct switch numbers");
            var beta=Enumerable.Range(0,8).Select(x=>new InputRef{Device=DemoData.Id,DeviceName="BETAFPV JoyStick",Kind="Axis",Index=x,Name=new[]{"X Axis","Y Axis","Throttle","X Rotation","Y Rotation","Rudder","Z Axis","Z Rotation"}[x]}).ToList();
            Assert(ControllerNames.Configure("43210483-0000-0000-0000-504944564944","BETAFPV JoyStick",beta),"Measured BETAFPV USB identity and layout are recognized");
            new Profile().ApplyControlLabels(beta);
            Assert(beta.Select(x=>x.ToString()).SequenceEqual(new[]{"Rotor","Collective","SA","Pitch","SC","SB","Roll","SD"}),"Recognized controller names work without a saved profile");
            var named=new Profile();named.NameControl(beta[0],"Tail rotor");named.ApplyControlLabels(beta);
            Assert(beta[0].ToString()=="Tail rotor","User rename overrides automatic controller name");
            named.NameControl(beta[0],"");named.ApplyControlLabels(beta);Assert(beta[0].ToString()=="Rotor","Clearing a rename restores the friendly default");
            named.Mappings.Add(new Mapping{Input=beta[2]});var restored=named.Clone();
            Assert(restored.Mappings[0].Input.ToString()=="SA","Device defaults survive save serialization for offline mapping cards");
            beta[0].Name="Different axis";Assert(!ControllerNames.Configure("43210483-0000-0000-0000-504944564944","BETAFPV JoyStick",beta),"Different BETAFPV layouts fall back instead of guessing switch names");
            Assert(!ControllerNames.Configure("other product","BETAFPV JoyStick",defaults),"Vendor name alone cannot select a controller layout");
            Assert(new InputRef{Kind="Axis",Index=0,Name="X Axis"}.ToString()=="Roll","Older profiles without defaults still get friendly names");
            Assert(new InputRef{Kind="Hat",Index=0,Direction=0}.ToString()=="Hat 1 Up","Hat directions retain their meaning");
            log.Add("\n"+log.Count+" checks passed. No keyboard, mouse, or virtual-device output was sent.");File.WriteAllLines(output,log);
        }
    }
}


