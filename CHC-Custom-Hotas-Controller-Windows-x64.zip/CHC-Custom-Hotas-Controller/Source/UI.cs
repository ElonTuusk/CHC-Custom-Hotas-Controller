using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;

namespace StickShift {
    class DeviceChoice {
        public string Id,Name; public List<InputRef> Inputs;
        public bool RecognizedLayout;
        public override string ToString() { return Name; }
    }
    class InputChoice {
        public InputRef Input;
        public override string ToString() { return Input.DeviceName+" / "+Input; }
    }
    public class UserInterface {
        public Window Window;
        Engine engine;
        Profile profile=new Profile();
        Profile beforeDemo;
        string profilePath,beforeDemoPath;
        bool dirty,beforeDemoDirty,loading,listing,listen;
        Dictionary<string,DeviceSample> listenBaseline;
        DateTime listenUntil;
        InputRef selected;
        string selectedMappingId;
        bool newAction;
        int mappingPage, mappingColumns=5, mappingRows=3;
        string mappingScope="";
        readonly Dictionary<string,Button> mappingButtons=new Dictionary<string,Button>();
        Mapping draft;
        TextBlock live;
        CurveView curve;
        DispatcherTimer timer;
        bool lastActive,shortcutRegistered;
        IntPtr handle;
        public bool Screenshot;
        [DllImport("user32")] static extern bool RegisterHotKey(IntPtr h,int id,uint mods,uint vk);
        [DllImport("user32")] static extern bool UnregisterHotKey(IntPtr h,int id);
        T C<T>(string name) where T:class { return Window.FindName(name) as T; }
        Button B(string n) { return C<Button>(n); }
        ListBox L(string n) { return C<ListBox>(n); }
        ComboBox Combo(string n) { return C<ComboBox>(n); }
        string Mode { get { return Combo("Modes").SelectedItem as string ?? "Base"; } }
        public UserInterface(bool screenshot) {
            Screenshot=screenshot;
            using(var stream=File.OpenRead(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Source","MainWindow.xaml"))) Window=(Window)XamlReader.Load(stream);
            Window.Icon=new BitmapImage(new Uri(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets","CHC.ico")));
            C<Image>("BrandIcon").Source=new BitmapImage(new Uri(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets","CHC.png")));
            engine=new Engine();
            if(!screenshot) {
                try {
                    string last=System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"LastProfile.txt");
                    string startup=File.Exists(last)?File.ReadAllText(last).Trim():System.IO.Path.Combine(ProfilesDir,"BETAFPV starter.xml");
                    if(File.Exists(startup)){profile=Profile.Load(startup);profilePath=startup;}
                } catch { /* A missing or invalid last profile must not prevent startup. */ }
            }
            Window.SourceInitialized+=delegate {
                handle=new WindowInteropHelper(Window).Handle;
                HwndSource.FromHwnd(handle).AddHook(Hook);
                shortcutRegistered=RegisterHotKey(handle,0x5353,0x4003,123);
                Scan();
                if(Screenshot) { C<CheckBox>("Demo").IsChecked=true; }
            };
            Window.Closing+=delegate(object s,System.ComponentModel.CancelEventArgs e) { engine.Stop();if(!ConfirmUnsaved())e.Cancel=true; };
            Window.Closed+=delegate { timer.Stop();UnregisterHotKey(handle,0x5353);engine.Dispose(); };
            C<TextBox>("ProfileName").TextChanged+=delegate { if(!loading){profile.Name=C<TextBox>("ProfileName").Text;MarkDirty();} };
            L("Devices").SelectionChanged+=delegate { if(!listing) FillInputs(); };
            L("Inputs").SelectionChanged+=delegate { if(!listing){selected=L("Inputs").SelectedItem as InputRef;selectedMappingId=null;newAction=false;BuildEditor();} };
            B("PreviousMappings").Click+=delegate{mappingPage--;RefreshMappings(false);};
            B("NextMappings").Click+=delegate{mappingPage++;RefreshMappings(false);};
            Window.SizeChanged+=delegate{ResizeMappingCards();};
            C<Border>("MappingPanel").SizeChanged+=delegate{ResizeMappingCards();};
            Combo("Filter").ItemsSource=new[]{"All inputs","Axes","Buttons","Hats"};Combo("Filter").SelectedIndex=0;
            Combo("Filter").SelectionChanged+=delegate { if(!listing)FillInputs(); };
            Combo("Modes").SelectionChanged+=delegate { if(!loading){try{engine.ChangeMode(Mode);}catch(Exception ex){engine.Stop();Error(ex);}RefreshMappings();BuildEditor();} };
            B("Refresh").Click+=delegate { Scan(); };
            B("New").Click+=delegate { if(!ConfirmUnsaved())return;profile=new Profile();profilePath=null;dirty=false;LoadProfile(); };
            B("Open").Click+=delegate { Open(); };
            B("Save").Click+=delegate { Save(false); };
            B("SaveAs").Click+=delegate { Save(true); };
            B("Start").Click+=delegate { StartStop(); };
            B("AddMode").Click+=delegate { AddMode(); };
            B("DeleteMode").Click+=delegate { RemoveMode(); };
            B("Guide").Click+=delegate { ShowGuide(); };
            B("VJoySetup").Click+=delegate { SetupVJoy(); };
            B("Listen").Click+=delegate { BeginListen(); };
            C<CheckBox>("Demo").Click+=delegate { ToggleDemo(); };
            C<CheckBox>("Demo").Checked+=delegate { if(Screenshot)ToggleDemo(); };
            LoadProfile();
            timer=new DispatcherTimer { Interval=TimeSpan.FromMilliseconds(40) };timer.Tick+=delegate{Tick();};timer.Start();
            if(Screenshot) Window.ContentRendered+=delegate {
                Window.Dispatcher.BeginInvoke(new Action(delegate {
                    VerifyUI();
                    Window.UpdateLayout();
                    var content=(FrameworkElement)Window.Content;
                    var bitmap=new RenderTargetBitmap((int)content.ActualWidth,(int)content.ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(content);
                    var enc=new PngBitmapEncoder();enc.Frames.Add(BitmapFrame.Create(bitmap));
                    using(var file=File.Create(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Preview.png")))enc.Save(file);
                    dirty=false;Window.Close();
                }),DispatcherPriority.ApplicationIdle);
            };
        }
        void VerifyUI() {
            var results=new List<string>();
            Action<bool,string> check=delegate(bool ok,string name){if(!ok)throw new Exception("UI check failed: "+name);results.Add("PASS  "+name);};
            check(profile.Mappings.Count==7,"Demo opens with seven mappings");
            var trigger=profile.Mappings.First(x=>x.Input.Kind=="Button"&&x.Input.Index==0);
            mappingButtons[trigger.Id].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(draft.Id==trigger.Id&&selected.Key==trigger.Input.Key,"Mapping button opens the exact assigned action");
            var action=C<StackPanel>("Editor").Children.OfType<ComboBox>().First();action.SelectedItem="Keyboard";
            var fields=C<StackPanel>("Editor").Children.OfType<StackPanel>().First(x=>x.Children.OfType<TextBox>().Any());var entry=fields.Children.OfType<TextBox>().First();entry.Text="Ctrl+Space";
            ((Button)C<StackPanel>("EditorButtons").Children[0]).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(profile.Mappings.First(x=>x.Input.Kind=="Button"&&x.Input.Index==0).Keys=="Ctrl+Space","Editor action change and Apply persist chord");
            Combo("Modes").SelectedItem="Flight";
            ((Button)C<StackPanel>("EditorButtons").Children[0]).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(profile.Mappings.Any(x=>x.Mode=="Flight"&&x.Input.Kind=="Button"),"Applying inherited mapping creates mode override");
            L("Inputs").SelectedItem=((IEnumerable<InputRef>)L("Inputs").ItemsSource).First(x=>x.Kind=="Axis"&&x.Index==0);
            action=C<StackPanel>("Editor").Children.OfType<ComboBox>().First();action.SelectedItem="Virtual button";
            ((Button)C<StackPanel>("EditorButtons").Children[0]).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(profile.Mappings.Any(x=>x.Mode=="Flight"&&x.Input.Kind=="Axis"&&x.Action=="Virtual button"),"Axis range mapping is editable and applicable");
            StartStop();check(engine.Active&&!C<StackPanel>("EditorButtons").IsEnabled,"Running demo locks editing");
            StartStop();check(!engine.Active&&C<StackPanel>("EditorButtons").IsEnabled,"Stop restores editing");
            var copy=profile.Clone();copy.Validate();check(copy.Modes.Count==2,"Edited profile validates and clones");
            var replaced=profile.Mappings.First(x=>x.Id==selectedMappingId);ApplySwitchPreset(3,2,replaced);
            check(profile.Visible(Mode).Count(x=>x.Input.Key==selected.Key)==3,"Three-position setup creates three actions on one input");
            check(profile.Visible(Mode).Where(x=>x.Input.Key==selected.Key).All(x=>mappingButtons.ContainsKey(x.Id)),"Each new switch position appears as a mapping button");
            var assignment=C<StackPanel>("Editor").Children.OfType<Grid>().SelectMany(x=>x.Children.OfType<ComboBox>()).First();assignment.SelectedIndex=1;
            string editing=draft.Id;draft.Target=6;
            ((Button)C<StackPanel>("EditorButtons").Children[0]).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(profile.Mappings.First(x=>x.Id==editing).Target==6&&profile.Visible(Mode).Count(x=>x.Input.Key==selected.Key)==3,"Editing one position preserves other positions");
            profile.NameControl(selected,"SB");FillDevices();RefreshMappings();check(selected.ToString()=="SB"&&profile.Visible(Mode).Where(x=>x.Input.Key==selected.Key).All(x=>x.ToString().StartsWith("SB")),"Switch name displays in input list and every action");
            ((Button)C<StackPanel>("EditorButtons").Children[1]).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(profile.Visible(Mode).Count(x=>x.Input.Key==selected.Key)==2,"Remove action removes only the selected position");
            for(int i=0;i<24;i++)profile.Mappings.Add(new Mapping{Input=DemoData.Ref("Button",5),Target=i,Label="Extra action "+i});
            selectedMappingId=null;RefreshMappings();var firstPage=new HashSet<string>(mappingButtons.Keys);
            B("NextMappings").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(!mappingButtons.Keys.Any(firstPage.Contains)&&mappingButtons.Count>0,"Next page exposes additional mapping buttons without scrolling");
            var later=mappingButtons.Values.First();var laterMap=(Mapping)later.Tag;later.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            check(selectedMappingId==laterMap.Id&&draft.Target==laterMap.Target,"A mapping on a later page opens the correct action");
            profile=new Profile();LoadProfile();check(mappingButtons.Count==0&&C<Border>("MappingEmpty").Visibility==Visibility.Visible,"Empty profile displays the add-mapping hint");
            check(((IEnumerable<InputRef>)L("Inputs").ItemsSource).Where(x=>x.Kind=="Axis").Take(4).Select(x=>x.ToString()).SequenceEqual(new[]{"Roll","Pitch","Collective","Rotor"}),"New profile displays friendly flight-axis names without saved labels");
            profile=DemoData.Profile();dirty=false;selected=null;selectedMappingId=null;newAction=false;LoadProfile();Tick();
            File.WriteAllLines(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"UI Test Results.txt"),results);
        }
        IntPtr Hook(IntPtr hwnd,int msg,IntPtr w,IntPtr l,ref bool handled) { if(msg==0x312 && w.ToInt32()==0x5353){engine.Stop();handled=true;}return IntPtr.Zero; }
        void Scan() {
            try { engine.Scan(handle);FillDevices();C<TextBlock>("Driver").Text=engine.VJoy.Information; }
            catch(Exception e){Error(e);}
        }
        void FillDevices() {
            string old=(L("Devices").SelectedItem as DeviceChoice ?? new DeviceChoice()).Id;
            var choices=new List<DeviceChoice>();
            lock(engine.Gate) {
                if(engine.Demo) choices.Add(new DeviceChoice {Id=DemoData.Id,Name="Demo flight controller",Inputs=DemoData.Inputs()});
                else {
                    choices.AddRange(engine.Hub.Devices.Select(x=>new DeviceChoice{Id=x.Id,Name=x.Name,Inputs=x.Inputs,RecognizedLayout=x.RecognizedLayout}));
                    foreach(var g in profile.Mappings.Select(x=>x.Input).GroupBy(x=>x.Device)) if(!choices.Any(x=>x.Id==g.Key))
                        choices.Add(new DeviceChoice{Id=g.Key,Name=g.First().DeviceName+" (offline)",Inputs=g.GroupBy(x=>x.Key).Select(x=>x.First()).ToList()});
                }
            }
            foreach(var choice in choices)profile.ApplyControlLabels(choice.Inputs);
            listing=true;L("Devices").ItemsSource=choices;L("Devices").SelectedItem=choices.FirstOrDefault(x=>x.Id==old)??choices.FirstOrDefault();listing=false;FillInputs();
            C<TextBlock>("Subtitle").Text=choices.Count==0?"Connect your joystick, throttle, or pedals, then refresh devices.":engine.Demo?"DEMO PREVIEW · Simulated controls. No output is sent to your games.":"Name your controls. Map each position. Make them feel right.";
        }
        void FillInputs() {
            var d=L("Devices").SelectedItem as DeviceChoice;
            var list=d==null?new List<InputRef>():d.Inputs;
            string filter=Combo("Filter").SelectedItem as string;
            if(filter=="Axes")list=list.Where(x=>x.Kind=="Axis").ToList();
            if(filter=="Buttons")list=list.Where(x=>x.Kind=="Button").ToList();
            if(filter=="Hats")list=list.Where(x=>x.Kind=="Hat").ToList();
            listing=true;L("Inputs").ItemsSource=list;L("Inputs").SelectedItem=selected==null?list.FirstOrDefault():list.FirstOrDefault(x=>x.Key==selected.Key)??list.FirstOrDefault();listing=false;
            selected=L("Inputs").SelectedItem as InputRef;BuildEditor();
            C<TextBlock>("InputHint").Text=d==null?"Or select an input below.":d.RecognizedLayout?"BETAFPV layout recognized.":"Default names. Move a control to check; use Rename if needed.";
        }
        void LoadProfile() {
            loading=true;C<TextBox>("ProfileName").Text=profile.Name;Combo("Modes").ItemsSource=profile.Modes.ToArray();Combo("Modes").SelectedItem="Base";loading=false;
            FillDevices();RefreshMappings();UpdateTitle();
        }
        void ResizeMappingCards() {
            int columns=Math.Max(3,Math.Min(7,(int)((C<Border>("MappingPanel").ActualWidth-32)/180)));
            int rows=Window.ActualHeight<800?2:3;
            if(columns==mappingColumns&&rows==mappingRows)return;
            mappingColumns=columns;mappingRows=rows;RefreshMappings();
        }
        void RefreshMappings(bool revealSelection=true) {
            var maps=profile.Visible(Mode).OrderBy(x=>x.Input.DeviceName).ThenBy(x=>x.Input.Kind).ThenBy(x=>x.Input.Index).ToList();
            if(mappingScope!=Mode){mappingScope=Mode;mappingPage=0;}
            int capacity=mappingColumns*mappingRows;
            int selectedIndex=maps.FindIndex(x=>x.Id==selectedMappingId);
            if(revealSelection&&selectedIndex>=0)mappingPage=selectedIndex/capacity;
            int pages=Math.Max(1,(maps.Count+capacity-1)/capacity);mappingPage=Math.Max(0,Math.Min(pages-1,mappingPage));
            var cards=C<UniformGrid>("MappingCards");cards.Columns=mappingColumns;cards.Children.Clear();mappingButtons.Clear();
            foreach(var m in maps.Skip(mappingPage*capacity).Take(capacity)) {
                var content=new StackPanel{HorizontalAlignment=HorizontalAlignment.Left};
                var title=Text(m.Input.ToString(),15);title.FontWeight=FontWeights.SemiBold;title.TextWrapping=TextWrapping.NoWrap;title.TextTrimming=TextTrimming.CharacterEllipsis;content.Children.Add(title);
                var destination=Text(MappingDestination(m),12);destination.TextWrapping=TextWrapping.NoWrap;destination.TextTrimming=TextTrimming.CharacterEllipsis;destination.Foreground=Brush("#AED3C5");destination.Margin=new Thickness(0,3,0,0);content.Children.Add(destination);
                string detail=!m.Enabled?"Paused":!String.IsNullOrWhiteSpace(m.Label)?m.Label:m.Input.Kind=="Axis"&&m.Action!="Virtual axis"?m.RangeMin.ToString("0.00")+" to "+m.RangeMax.ToString("0.00"):m.Action;
                if(m.Mode!=Mode)detail+=" · Base";
                var label=Text(detail,10);label.Foreground=Brush("#8CA8A0");label.TextWrapping=TextWrapping.NoWrap;label.TextTrimming=TextTrimming.CharacterEllipsis;label.Margin=new Thickness(0,4,0,0);content.Children.Add(label);
                var button=new Button{Content=content,Tag=m,Height=86,Padding=new Thickness(13,9,13,9),Margin=new Thickness(4),HorizontalContentAlignment=HorizontalAlignment.Stretch,ToolTip=m.ToString()+"\n"+m.Input.DeviceName+" · "+m.Mode};
                // The card content stretches so long user names truncate inside the button.
                button.Template=MappingButtonTemplate();
                System.Windows.Automation.AutomationProperties.SetName(button,m.ToString());
                button.Click+=delegate{SelectMapping(m);};cards.Children.Add(button);mappingButtons[m.Id]=button;
            }
            C<TextBlock>("MappingCount").Text=Mode+"  ·  "+maps.Count+" action"+(maps.Count==1?"":"s")+"  ·  Select a button to edit";
            C<StackPanel>("MappingPager").Visibility=pages>1?Visibility.Visible:Visibility.Collapsed;
            C<TextBlock>("MappingPage").Text=(mappingPage+1)+" / "+pages;
            B("PreviousMappings").IsEnabled=mappingPage>0;B("NextMappings").IsEnabled=mappingPage<pages-1;
            C<Border>("MappingEmpty").Visibility=maps.Count==0?Visibility.Visible:Visibility.Collapsed;
            HighlightMappingCards();
        }
        static ControlTemplate mappingButtonTemplate;
        static ControlTemplate MappingButtonTemplate() {
            if(mappingButtonTemplate==null)mappingButtonTemplate=(ControlTemplate)XamlReader.Parse("<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='Button'><Border x:Name='box' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='{TemplateBinding BorderThickness}' CornerRadius='8' Padding='{TemplateBinding Padding}'><ContentPresenter HorizontalAlignment='Stretch' VerticalAlignment='Center'/></Border><ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='box' Property='Opacity' Value='0.8'/></Trigger><Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='box' Property='BorderBrush' Value='#EDF3F2'/></Trigger></ControlTemplate.Triggers></ControlTemplate>");
            return mappingButtonTemplate;
        }
        static string MappingDestination(Mapping m) {
            if(m.Action=="Virtual axis")return "vJoy "+m.VJoy+"  →  "+InputRef.AxisNames[m.Target];
            if(m.Action=="Virtual button")return "vJoy "+m.VJoy+"  →  Button "+(m.Target+1);
            if(m.Action=="Virtual hat")return "vJoy "+m.VJoy+"  →  Hat "+(m.Target+1);
            if(m.Action=="Keyboard")return m.Keys;
            if(m.Action=="Switch mode")return "Mode  →  "+m.SwitchMode;
            if(m.Action=="Mouse button")return new[]{"Left click","Right click","Middle click"}[m.Target];
            return "Macro sequence";
        }
        void HighlightMappingCards() {
            foreach(var pair in mappingButtons){bool chosen=!newAction&&pair.Key==selectedMappingId;var b=pair.Value;b.Background=Brush(chosen?"#294C41":"#202F32");b.BorderBrush=Brush(chosen?"#83E3BE":"#3B4E4B");b.BorderThickness=new Thickness(chosen?2:1);b.Opacity=((Mapping)b.Tag).Enabled?1:.55;}
        }
        void SelectMapping(Mapping m) {
            selected=m.Input;selectedMappingId=m.Id;newAction=false;
            listing=true;Combo("Filter").SelectedIndex=0;L("Devices").SelectedItem=((IEnumerable<DeviceChoice>)L("Devices").ItemsSource).FirstOrDefault(x=>x.Id==m.Input.Device);listing=false;FillInputs();
            L("Inputs").ScrollIntoView(L("Inputs").SelectedItem);
        }
        void MarkDirty(){dirty=true;UpdateTitle();}
        void UpdateTitle(){Window.Title="CHC Custom Hotas Controller · "+profile.Name+(dirty?" *":"");}
        void Open() {
            if(!ConfirmUnsaved())return;
            var d=new OpenFileDialog{Filter="CHC Custom Hotas Controller profiles (*.xml)|*.xml",InitialDirectory=ProfilesDir};
            if(d.ShowDialog(Window)!=true)return;
            try{var p=Profile.Load(d.FileName);profile=p;profilePath=d.FileName;dirty=false;LoadProfile();}catch(Exception e){Error(e);}
        }
        string ProfilesDir {get{return System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Profiles");}}
        bool Save(bool saveAs) {
            string path=profilePath;
            if(saveAs || path==null) {
                var d=new SaveFileDialog{Filter="CHC Custom Hotas Controller profiles (*.xml)|*.xml",InitialDirectory=ProfilesDir,FileName="My controls.xml",DefaultExt=".xml"};
                if(d.ShowDialog(Window)!=true)return false;path=d.FileName;
            }
            try{profile.Save(path);profilePath=path;dirty=false;if(!engine.Demo)File.WriteAllText(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"LastProfile.txt"),path);UpdateTitle();C<TextBlock>("Status").Text="Saved "+path;return true;}catch(Exception e){Error(e);return false;}
        }
        bool ConfirmUnsaved() {
            if(!dirty)return true;
            var answer=MessageBox.Show(Window,"Save changes to "+profile.Name+"?","Unsaved profile",MessageBoxButton.YesNoCancel,MessageBoxImage.Question);
            return answer==MessageBoxResult.No || (answer==MessageBoxResult.Yes && Save(false));
        }
        void StartStop() {
            try{if(engine.Active)engine.Stop();else engine.Start(profile,Mode);}catch(Exception e){Error(e);}Tick();
        }
        void ToggleDemo() {
            bool on=C<CheckBox>("Demo").IsChecked==true;
            if(on){beforeDemo=profile;beforeDemoPath=profilePath;beforeDemoDirty=dirty;profile=DemoData.Profile();profilePath=null;dirty=false;}
            else {
                if(!ConfirmUnsaved()){loading=true;C<CheckBox>("Demo").IsChecked=true;loading=false;return;}
                profile=beforeDemo??new Profile();profilePath=beforeDemoPath;dirty=beforeDemoDirty;
            }
            engine.SetDemo(on);LoadProfile();
        }
        void AddMode() {
            string name=Prompt("Add a mode","Mode name (inherits Base mappings)","");
            if(name==null)return;name=name.Trim();
            if(name.Length==0 || name.Length>48 || profile.Modes.Contains(name)){MessageBox.Show(Window,"Choose a unique name from 1 to 48 characters.");return;}
            profile.Modes.Add(name);loading=true;Combo("Modes").ItemsSource=profile.Modes.ToArray();Combo("Modes").SelectedItem=name;loading=false;MarkDirty();RefreshMappings();BuildEditor();
        }
        void RemoveMode() {
            string mode=Mode;if(mode=="Base"){MessageBox.Show(Window,"Base is the shared mode and cannot be removed.");return;}
            if(MessageBox.Show(Window,"Remove "+mode+" and its mappings? Actions that switch to it will switch to Base.","Remove mode",MessageBoxButton.OKCancel)!=MessageBoxResult.OK)return;
            profile.Modes.Remove(mode);profile.Mappings.RemoveAll(m=>m.Mode==mode);foreach(var m in profile.Mappings.Where(x=>x.SwitchMode==mode))m.SwitchMode="Base";MarkDirty();LoadProfile();
        }
        string Prompt(string title,string label,string initial) {
            var p=new StackPanel{Margin=new Thickness(22)};p.Children.Add(Text(label,13));var t=new TextBox{Text=initial,Margin=new Thickness(0,12,0,16)};p.Children.Add(t);
            var ok=new Button{Content="Done",IsDefault=true};p.Children.Add(ok);
            var w=new Window{Title=title,Content=p,Width=390,SizeToContent=SizeToContent.Height,ResizeMode=ResizeMode.NoResize,Owner=Window,WindowStartupLocation=WindowStartupLocation.CenterOwner,Background=Brush("#182225"),Foreground=Brush("#EDF3F2"),Resources=Window.Resources};
            ok.Click+=delegate{w.DialogResult=true;};w.Loaded+=delegate{t.Focus();};return w.ShowDialog()==true?t.Text:null;
        }
        void SetupVJoy() {
            string exe=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"vJoy","x64","vJoyConf.exe");
            MessageBox.Show(Window,engine.VJoy.Describe()+"\n\nEnable the axes, buttons, and continuous hats your mappings need. Close other mappers before starting CHC.","vJoy setup");
            if(File.Exists(exe))try{System.Diagnostics.Process.Start(exe);}catch(Exception e){Error(e);}
        }
        void ShowGuide() { var path=System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Quick Guide.html");System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path){UseShellExecute=true}); }
        void BeginListen() {
            if(listen){listen=false;B("Listen").Content="◎  Detect my next input";return;}
            lock(engine.Gate)listenBaseline=new Dictionary<string,DeviceSample>(engine.Samples);
            listen=true;listenUntil=DateTime.UtcNow.AddSeconds(12);B("Listen").Content="Listening… click to cancel";C<TextBlock>("InputHint").Text="Move an axis or press a button on any controller.";
        }
        void Tick() {
            Dictionary<string,DeviceSample> samples;bool active;string status,mode;
            lock(engine.Gate){samples=new Dictionary<string,DeviceSample>(engine.Samples);active=engine.Active;status=engine.Status;mode=engine.Mode;}
            C<TextBlock>("Status").Text=status;
            C<TextBlock>("StateTag").Text=active?(engine.Demo?"●  DEMO RUNNING":"●  ACTIVE"):"●  STOPPED";
            C<TextBlock>("StateTag").Foreground=Brush(active?"#83E3BE":"#A4B8B9");
            B("Start").Content=active?"■  Stop mappings":engine.Demo?"▶  Run demo":"▶  Start mappings";
            if(active!=lastActive){lastActive=active;foreach(var n in new[]{"New","Open","Save","SaveAs","Refresh","AddMode","DeleteMode","VJoySetup"})B(n).IsEnabled=!active;C<CheckBox>("Demo").IsEnabled=!active;C<TextBox>("ProfileName").IsReadOnly=active;C<StackPanel>("Editor").IsEnabled=!active;C<StackPanel>("EditorButtons").IsEnabled=!active;}
            C<TextBlock>("StateHint").Text=!shortcutRegistered?"Stop shortcut unavailable. Use the Stop button.":active?"Ctrl + Alt + F12 to stop · Stop before editing mappings.":"Changes apply when you start. Base mappings carry into every mode.";
            if(active && mode!=Mode){loading=true;Combo("Modes").SelectedItem=mode;loading=false;RefreshMappings();BuildEditor();}
            if(selected!=null && live!=null){DeviceSample s;if(samples.TryGetValue(selected.Device,out s)&&s.Connected){double v=s.Value(selected);live.Text=selected.Kind=="Axis"?"INPUT  "+v.ToString("+0.000;-0.000;0.000"):selected.Kind=="Hat"&&selected.Direction<0?(v<0?"CENTERED":"ANGLE  "+(v/100)+"°"):(v>0?"●  PRESSED":"○  RELEASED");if(curve!=null){curve.Value=v;curve.InvalidateVisual();}}else live.Text="DEVICE OFFLINE";}
            if(listen) {
                InputRef found=null;
                foreach(var d in (IEnumerable<DeviceChoice>)L("Devices").ItemsSource){DeviceSample now,prior;if(!samples.TryGetValue(d.Id,out now)||!now.Connected||!listenBaseline.TryGetValue(d.Id,out prior))continue;
                    found=d.Inputs.FirstOrDefault(i=>i.Kind=="Axis"?Math.Abs(now.Value(i)-prior.Value(i))>.22:i.Kind=="Hat"&&i.Direction<0?false:now.Value(i)>.5&&prior.Value(i)<.5);if(found!=null)break;}
                if(found!=null){selected=found;listing=true;Combo("Filter").SelectedIndex=0;L("Devices").SelectedItem=((IEnumerable<DeviceChoice>)L("Devices").ItemsSource).First(d=>d.Id==found.Device);listing=false;FillInputs();L("Inputs").ScrollIntoView(L("Inputs").SelectedItem);listen=false;C<TextBlock>("InputHint").Text="Detected: "+found;}
                else if(DateTime.UtcNow>listenUntil){listen=false;C<TextBlock>("InputHint").Text="No movement detected. Try again or select an input.";}
                if(!listen)B("Listen").Content="◎  Detect my next input";
            }
        }
        void Error(Exception e){MessageBox.Show(Window,e.GetBaseException().Message,"CHC Custom Hotas Controller",MessageBoxButton.OK,MessageBoxImage.Information);}
        static SolidColorBrush Brush(string hex){return (SolidColorBrush)new BrushConverter().ConvertFromString(hex);}
        static TextBlock Text(string value,double size=13){return new TextBlock{Text=value,FontSize=size,TextWrapping=TextWrapping.Wrap};}
        void BuildEditor() {
            var panel=C<StackPanel>("Editor");panel.Children.Clear();live=null;curve=null;panel.IsEnabled=!engine.Active;
            var controls=C<StackPanel>("EditorButtons");controls.Children.Clear();controls.IsEnabled=!engine.Active;
            if(selected==null) {
                panel.Children.Add(Text("A better starting point.",27));
                var desc=Text("Connect your controls and select Refresh devices. Then choose an input here, or let CHC detect your next movement.",15);desc.Foreground=Brush("#9DB2B0");desc.Margin=new Thickness(0,18,0,24);panel.Children.Add(desc);
                panel.Children.Add(Text("Just looking around?",15));
                var hint=Text("Turn on Explore demo controller in the sidebar to try curves, mappings, and profiles without sending any output.",13);hint.Foreground=Brush("#9DB2B0");hint.Margin=new Thickness(0,10,0,24);panel.Children.Add(hint);
                panel.Children.Add(Text("01  Choose an input\n\n02  Choose an action\n\n03  Save your profile and start",16));return;
            }
            var options=profile.Visible(Mode).Where(x=>x.Input.Key==selected.Key).ToList();
            var source=newAction?null:options.FirstOrDefault(x=>x.Id==selectedMappingId)??options.FirstOrDefault();
            if(!newAction)selectedMappingId=source==null?null:source.Id;
            HighlightMappingCards();
            var original=source!=null&&source.Mode==Mode?source:null;
            var inherited=source!=null&&source.Mode!=Mode?source:null;
            // Reuse serialization to ensure edits stay separate until Apply.
            draft=source==null?new Mapping{Input=selected,Mode=Mode,Action=selected.Kind=="Axis"?"Virtual axis":selected.Kind=="Hat"&&selected.Direction<0?"Virtual hat":"Virtual button"}:new Profile{Mappings=new List<Mapping>{source}}.Clone().Mappings[0];
            if(original==null){draft.Id=Guid.NewGuid().ToString();draft.Mode=Mode;}
            var titleRow=new DockPanel();panel.Children.Add(titleRow);
            var rename=new Button{Content="Rename",Padding=new Thickness(10,6,10,6),Margin=new Thickness(12,0,0,0),VerticalAlignment=VerticalAlignment.Top};DockPanel.SetDock(rename,Dock.Right);titleRow.Children.Add(rename);
            rename.Click+=delegate{string name=Prompt("Name this control","Physical name, such as SA, Arm switch, or Throttle (blank resets)",selected.Alias);if(name==null)return;if(name.Trim().Length>64){MessageBox.Show(Window,"Use a name up to 64 characters.");return;}profile.NameControl(selected,name);MarkDirty();FillDevices();RefreshMappings();};
            var title=Text(selected.ToString(),26);title.FontWeight=FontWeights.SemiBold;title.ToolTip="Reported by Windows: "+selected.Name+" / channel "+(selected.Index+1);titleRow.Children.Add(title);
            live=Text("INPUT  —",12);live.Foreground=Brush("#83E3BE");live.Margin=new Thickness(0,7,0,16);panel.Children.Add(live);
            if(options.Count>0) {
                var assignmentRow=new Grid{Margin=new Thickness(0,0,0,12)};assignmentRow.ColumnDefinitions.Add(new ColumnDefinition());assignmentRow.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});panel.Children.Add(assignmentRow);
                var assignment=new ComboBox{Name="Assignments",ItemsSource=options,SelectedItem=source,Margin=new Thickness(0,0,8,0),ToolTip="Choose the action or switch position to edit"};assignmentRow.Children.Add(assignment);
                assignment.SelectionChanged+=delegate{var chosen=assignment.SelectedItem as Mapping;if(chosen!=null){selectedMappingId=chosen.Id;newAction=false;BuildEditor();}};
                var add=new Button{Content="+ Add action"};Grid.SetColumn(add,1);assignmentRow.Children.Add(add);add.Click+=delegate{selectedMappingId=null;newAction=true;BuildEditor();};
            }
            if(selected.Kind=="Axis") {
                var presets=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,0,0,12)};panel.Children.Add(presets);
                foreach(int count in new[]{2,3}) {int positions=count;var preset=new Button{Content=count+"-position switch",Padding=new Thickness(10,7,10,7),Margin=new Thickness(0,0,8,0)};presets.Children.Add(preset);preset.Click+=delegate{SetupSwitch(positions,source);};}
            }
            if(inherited!=null){var notice=Text("Inherited from Base. Apply to create an override in "+Mode+".",12);notice.Foreground=Brush("#D6C591");notice.Margin=new Thickness(0,0,0,12);panel.Children.Add(notice);}
            Label(panel,"ACTION");
            var actions=selected.Kind=="Axis"?new[]{"Virtual axis","Virtual button","Keyboard","Macro","Switch mode","Mouse button"}:selected.Kind=="Hat"&&selected.Direction<0?new[]{"Virtual hat"}:new[]{"Virtual button","Keyboard","Macro","Switch mode","Mouse button"};
            var action=Select(panel,actions,draft.Action);
            var fields=new StackPanel{Margin=new Thickness(0,16,0,0)};panel.Children.Add(fields);
            Action render=delegate{RenderAction(fields);};
            action.SelectionChanged+=delegate{draft.Action=action.SelectedItem as string;draft.Target=0;draft.Toggle=false;render();};render();
            var adv=new Expander{Header="More options · label, condition, enable",Margin=new Thickness(0,18,0,12),Foreground=Brush("#A8BFBA")};var extra=new StackPanel{Margin=new Thickness(0,12,0,0)};adv.Content=extra;panel.Children.Add(adv);
            Label(extra,"LABEL (OPTIONAL)");var label=Entry(extra,draft.Label);label.TextChanged+=delegate{draft.Label=label.Text;};
            Check(extra,"Enable this mapping",draft.Enabled,v=>draft.Enabled=v);
            Label(extra,"ONLY WHILE THIS BUTTON IS HELD");var conditions=AllInputs().Where(x=>x.Kind=="Button"||x.Kind=="Hat"&&x.Direction>=0).ToList();ChooseInput(extra,conditions,draft.Condition,v=>draft.Condition=v,"Always active");
            var apply=new Button{Content=original==null?"+  Add mapping":"Apply changes",Background=Brush("#83E3BE"),Foreground=Brush("#102C22"),BorderBrush=Brush("#83E3BE"),MinWidth=140};controls.Children.Add(apply);
            apply.Click+=delegate {
                try {
                    var candidate=profile.Clone();candidate.UpsertAction(draft,inherited==null?null:inherited.Id);candidate.Validate();profile=candidate;selectedMappingId=draft.Id;newAction=false;MarkDirty();RefreshMappings();BuildEditor();
                } catch(Exception e){Error(e);}
            };
            if(original!=null){var remove=new Button{Content="Remove action",Margin=new Thickness(10,0,0,0)};controls.Children.Add(remove);remove.Click+=delegate{profile.Mappings.RemoveAll(x=>x.Id==original.Id);selectedMappingId=null;newAction=false;MarkDirty();RefreshMappings();BuildEditor();};}
        }
        void SetupSwitch(int count,Mapping replaced) {
            var used=new HashSet<int>(profile.Effective(Mode).Where(x=>x.Action=="Virtual button"&&x.VJoy==draft.VJoy&&x!=replaced).Select(x=>x.Target+1));
            int suggested=Enumerable.Range(1,129-count).FirstOrDefault(n=>Enumerable.Range(n,count).All(b=>!used.Contains(b)));
            string text=Prompt(count+"-position switch","First button on vJoy "+draft.VJoy+" (uses "+count+" consecutive buttons)",Math.Max(1,suggested).ToString());
            if(text==null)return;int first;
            if(!Int32.TryParse(text,out first)||first<1||first+count-1>128){MessageBox.Show(Window,"Choose a first button from 1 to "+(129-count)+".");return;}
            try { ApplySwitchPreset(count,first,replaced); }catch(Exception e){Error(e);}
        }
        void ApplySwitchPreset(int count,int first,Mapping replaced) {
            var candidate=profile.Clone();
            // Materialize inherited siblings before replacing the selected action.
            var firstMap=new Mapping{Input=selected,Mode=Mode,Action="Virtual button",VJoy=draft.VJoy,Target=first-1,RangeMin=-1,RangeMax=count==2?-.05:-.5,Label="Low position"};
            if(replaced!=null&&replaced.Mode==Mode)firstMap.Id=replaced.Id;
            candidate.UpsertAction(firstMap,replaced!=null&&replaced.Mode!=Mode?replaced.Id:null);
            if(count==3)candidate.UpsertAction(new Mapping{Input=selected,Mode=Mode,Action="Virtual button",VJoy=draft.VJoy,Target=first,RangeMin=-.45,RangeMax=.45,Label="Middle position"},null);
            candidate.UpsertAction(new Mapping{Input=selected,Mode=Mode,Action="Virtual button",VJoy=draft.VJoy,Target=first+count-2,RangeMin=count==2?.05:.5,RangeMax=1,Label="High position"},null);
            candidate.Validate();profile=candidate;selectedMappingId=firstMap.Id;newAction=false;MarkDirty();RefreshMappings();BuildEditor();
        }
        List<InputRef> AllInputs(){return ((IEnumerable<DeviceChoice>)L("Devices").ItemsSource).SelectMany(x=>x.Inputs).ToList();}
        void RenderAction(StackPanel p) {
            p.Children.Clear();curve=null;
            if(selected.Kind=="Axis" && draft.Action!="Virtual axis") {
                Hint(p,"Activate this action while the axis is in the range below. Useful for RC switches reported as axes. A small hysteresis prevents chatter at the edges.");
                Slide(p,"Range start",draft.RangeMin,-1,.99,x=>draft.RangeMin=x,false);
                Slide(p,"Range end",draft.RangeMax,-.99,1,x=>draft.RangeMax=x,false);
            }
            if(draft.Action.StartsWith("Virtual")) {
                var row=new Grid();row.ColumnDefinitions.Add(new ColumnDefinition());row.ColumnDefinitions.Add(new ColumnDefinition());p.Children.Add(row);
                var left=new StackPanel{Margin=new Thickness(0,0,8,0)};var right=new StackPanel{Margin=new Thickness(8,0,0,0)};row.Children.Add(left);row.Children.Add(right);Grid.SetColumn(right,1);
                Label(left,"OUTPUT DEVICE");var device=Select(left,Enumerable.Range(1,16).Select(x=>"vJoy "+x),"vJoy "+draft.VJoy);device.SelectionChanged+=delegate{draft.VJoy=device.SelectedIndex+1;};
                Label(right,"OUTPUT INPUT");var names=draft.Action=="Virtual axis"?InputRef.AxisNames:draft.Action=="Virtual hat"?Enumerable.Range(1,4).Select(x=>"Hat "+x).ToArray():Enumerable.Range(1,128).Select(x=>"Button "+x).ToArray();
                var target=Select(right,names,names[Math.Min(draft.Target,names.Length-1)]);target.SelectionChanged+=delegate{draft.Target=target.SelectedIndex;};
            }
            if(draft.Action=="Virtual axis") {
                var graphRow=new Grid{Margin=new Thickness(0,14,0,8)};graphRow.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(2,GridUnitType.Star)});graphRow.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});p.Children.Add(graphRow);
                curve=new CurveView{Mapping=draft,Height=154,Margin=new Thickness(0,0,18,0)};graphRow.Children.Add(curve);
                var settings=new StackPanel();graphRow.Children.Add(settings);Grid.SetColumn(settings,1);
                var dz=new StackPanel();var response=new StackPanel();var saturation=new StackPanel();settings.Children.Add(dz);settings.Children.Add(response);settings.Children.Add(saturation);
                Slide(dz,"Dead zone",draft.Deadzone,0,.5,x=>{draft.Deadzone=x;if(draft.Saturation<=x)draft.Saturation=x+.01;},true);
                Slide(response,"Response",draft.Curve,-1,1,x=>draft.Curve=x,false);
                Slide(saturation,"Full output at",draft.Saturation,.51,1,x=>draft.Saturation=x,true);
                Check(p,"Invert this axis",draft.Invert,v=>draft.Invert=v);
                Check(p,"Throttle / pedal (dead zone at the start)",draft.Unipolar,v=>draft.Unipolar=v);
                var merge=new Expander{Header="Merge with another axis",Foreground=Brush("#A8BFBA"),Margin=new Thickness(0,10,0,0)};var inner=new StackPanel{Margin=new Thickness(0,10,0,0)};merge.Content=inner;p.Children.Add(merge);
                ChooseInput(inner,AllInputs().Where(x=>x.Kind=="Axis"&&x.Key!=selected.Key).ToList(),draft.Second,v=>draft.Second=v,"Do not merge");
                var method=Select(inner,new[]{"Average","Difference","Maximum","Minimum"},draft.Merge);method.Margin=new Thickness(0,8,0,0);method.SelectionChanged+=delegate{draft.Merge=method.SelectedItem as string;};
            }
            else if(draft.Action=="Keyboard") {Label(p,"KEY OR CHORD");var key=Entry(p,draft.Keys);key.TextChanged+=delegate{draft.Keys=key.Text;};Hint(p,"Examples: Space, Ctrl+G, RAlt+F, Num0, Left. Held for as long as the input is pressed.");}
            else if(draft.Action=="Macro") {
                Label(p,"SEQUENCE");var macro=Entry(p,draft.Macro);macro.AcceptsReturn=true;macro.Height=150;macro.FontFamily=new FontFamily("Consolas");macro.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;macro.TextChanged+=delegate{draft.Macro=macro.Text;};
                Hint(p,"One key or chord per line. WAIT 200 pauses for 200 ms. Each key press lasts 60 ms. Runs once per press; Stop cancels it.");
                Label(p,"REPEAT");var repeat=Select(p,Enumerable.Range(1,20).Select(x=>x.ToString()),draft.Repeat.ToString());repeat.SelectionChanged+=delegate{draft.Repeat=repeat.SelectedIndex+1;};
            }
            else if(draft.Action=="Switch mode") {Label(p,"SWITCH TO");var mo=Select(p,profile.Modes,draft.SwitchMode);mo.SelectionChanged+=delegate{draft.SwitchMode=mo.SelectedItem as string;};Hint(p,"Switches on press. Mode changes release held outputs and cancel macros. Base mappings are inherited.");}
            else if(draft.Action=="Mouse button") {Label(p,"MOUSE BUTTON");var mouse=Select(p,new[]{"Left","Right","Middle"},new[]{"Left","Right","Middle"}[Math.Min(draft.Target,2)]);mouse.SelectionChanged+=delegate{draft.Target=mouse.SelectedIndex;};}
            if(new[]{"Virtual button","Keyboard","Mouse button"}.Contains(draft.Action))Check(p,"Toggle on / off with each press",draft.Toggle,v=>draft.Toggle=v);
            if(draft.Action=="Virtual hat")Hint(p,"Passes all eight directions to a continuous vJoy hat. Choose an individual hat direction on the left to assign a key or button instead.");
        }
        static void Label(StackPanel p,string text){var t=Text(text,10);t.Foreground=Brush("#91A8A7");t.Margin=new Thickness(0,0,0,7);p.Children.Add(t);}
        static void Hint(StackPanel p,string text){var t=Text(text,12);t.Foreground=Brush("#8DA5A4");t.Margin=new Thickness(0,10,0,14);p.Children.Add(t);}
        static TextBox Entry(StackPanel p,string value){var t=new TextBox{Text=value};p.Children.Add(t);return t;}
        static ComboBox Select(StackPanel p,IEnumerable<string> choices,string selected){var c=new ComboBox{ItemsSource=choices.ToArray(),SelectedItem=selected};if(c.SelectedIndex<0)c.SelectedIndex=0;p.Children.Add(c);return c;}
        void Check(StackPanel p,string text,bool value,Action<bool> setter){var c=new CheckBox{Content=text,IsChecked=value};p.Children.Add(c);c.Click+=delegate{setter(c.IsChecked==true);if(curve!=null)curve.InvalidateVisual();};}
        void Slide(StackPanel p,string name,double value,double min,double max,Action<double> setter,bool percent){var label=Text(name+"   "+(percent?(value*100).ToString("0")+"%":value.ToString("+0.00;-0.00;0.00")),12);p.Children.Add(label);var slider=new Slider{Minimum=min,Maximum=max,Value=value,TickFrequency=.01,IsSnapToTickEnabled=true};p.Children.Add(slider);slider.ValueChanged+=delegate{setter(slider.Value);label.Text=name+"   "+(percent?(slider.Value*100).ToString("0")+"%":slider.Value.ToString("+0.00;-0.00;0.00"));if(curve!=null)curve.InvalidateVisual();};}
        void ChooseInput(StackPanel p,List<InputRef> choices,InputRef selectedInput,Action<InputRef> setter,string none){var list=new List<object>{none};list.AddRange(choices.Select(x=>new InputChoice{Input=x}));var c=new ComboBox{ItemsSource=list};c.SelectedItem=selectedInput==null?list[0]:list.OfType<InputChoice>().FirstOrDefault(x=>x.Input.Key==selectedInput.Key) as object??list[0];p.Children.Add(c);c.SelectionChanged+=delegate{var choice=c.SelectedItem as InputChoice;setter(choice==null?null:choice.Input);};}
    }
    public class CurveView : FrameworkElement {
        public Mapping Mapping; public double Value;
        protected override void OnRender(DrawingContext dc) {
            double w=ActualWidth,h=ActualHeight;var bounds=new Rect(0,0,w,h);dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(15,26,28)),null,bounds,7,7);
            double l=24,t=14,r=w-24,b=h-25;
            var grid=new Pen(new SolidColorBrush(Color.FromRgb(42,63,63)),1);
            for(int i=0;i<5;i++){double x=l+(r-l)*i/4;double y=t+(b-t)*i/4;dc.DrawLine(grid,new Point(x,t),new Point(x,b));dc.DrawLine(grid,new Point(l,y),new Point(r,y));}
            var ghost=new Pen(new SolidColorBrush(Color.FromRgb(78,95,94)),1){DashStyle=DashStyles.Dash};dc.DrawLine(ghost,new Point(l,b),new Point(r,t));
            var path=new StreamGeometry();using(var g=path.Open()){for(int i=0;i<=100;i++){double x=i/50.0-1,y=AxisMath.Apply(x,Mapping);var pt=new Point(l+(x+1)*.5*(r-l),b-(y+1)*.5*(b-t));if(i==0)g.BeginFigure(pt,false,false);else g.LineTo(pt,true,false);}}
            var mint=new SolidColorBrush(Color.FromRgb(131,227,190));dc.DrawGeometry(null,new Pen(mint,2.5),path);
            double vx=Math.Max(-1,Math.Min(1,Value)),vy=AxisMath.Apply(vx,Mapping);dc.DrawEllipse(mint,new Pen(Brushes.White,1),new Point(l+(vx+1)*.5*(r-l),b-(vy+1)*.5*(b-t)),4,4);
            var label=new FormattedText("RESPONSE PREVIEW",System.Globalization.CultureInfo.InvariantCulture,FlowDirection.LeftToRight,new Typeface("Segoe UI"),9,new SolidColorBrush(Color.FromRgb(141,169,163)));
            dc.DrawText(label,new Point(l,h-17));
        }
    }
}



