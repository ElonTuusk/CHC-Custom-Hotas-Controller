using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;

namespace StickShift {
    public class InputRef {
        public string Device = "";
        public string DeviceName = "";
        public string Kind = "Button";
        public int Index;
        public int Direction = -1;
        public string Name = "";
        public string Alias = "";
        // A device default is separate from a profile's explicit rename.
        public string DefaultName = "";
        public string Key { get { return Device + "/" + Kind + "/" + Index + "/" + Direction; } }
        public override string ToString() {
            if(!String.IsNullOrWhiteSpace(Alias))return Alias;
            if(!String.IsNullOrWhiteSpace(DefaultName))return DefaultName;
            if (Kind == "Axis") return ControllerNames.GenericAxis(Index);
            if (Kind == "Hat") return "Hat " + (Index + 1) + (Direction < 0 ? " (all directions)" : " " + Directions[Direction]);
            return "Switch " + (Index + 1);
        }
        public static readonly string[] AxisNames = { "X", "Y", "Z", "Rotation X", "Rotation Y", "Rotation Z", "Slider 1", "Slider 2" };
        public static readonly string[] Directions = { "Up", "Up-right", "Right", "Down-right", "Down", "Down-left", "Left", "Up-left" };
    }
    public static class ControllerNames {
        public static readonly string[] FlightAxes = { "Roll", "Pitch", "Collective", "Rotor" };
        static readonly string[] BetaAxisNames = { "X Axis", "Y Axis", "Throttle", "X Rotation", "Y Rotation", "Rudder", "Z Axis", "Z Rotation" };
        static readonly string[] BetaLabels = { "Rotor", "Collective", "SA", "Pitch", "SC", "SB", "Roll", "SD" };
        public static string GenericAxis(int index) { return index<4 && index>=0 ? FlightAxes[index] : "Switch " + (index-3); }
        public static bool Configure(string product,string deviceName,IEnumerable<InputRef> inputs) {
            var list=inputs.ToList();var axes=list.Where(x=>x.Kind=="Axis").OrderBy(x=>x.Index).ToList();
            // Only use the measured LiteRadio layout when its full USB identity
            // and ordered axis layout match. A vendor name alone is insufficient.
            bool beta=String.Equals(product,"43210483-0000-0000-0000-504944564944",StringComparison.OrdinalIgnoreCase)
                && (deviceName??"").IndexOf("BETAFPV",StringComparison.OrdinalIgnoreCase)>=0
                && axes.Count==8 && axes.Select(x=>x.Index).SequenceEqual(Enumerable.Range(0,8))
                && axes.Select(x=>x.Name).SequenceEqual(BetaAxisNames,StringComparer.OrdinalIgnoreCase);
            foreach(var input in list) {
                if(input.Kind=="Axis")input.DefaultName=beta?BetaLabels[input.Index]:GenericAxis(input.Index);
                else if(input.Kind=="Button")input.DefaultName="Switch "+(Math.Max(0,axes.Count-4)+input.Index+1);
                else input.DefaultName="";
            }
            return beta;
        }
    }
    public class ControlLabel {
        public string Key = "";
        public string Name = "";
    }
    public class Mapping {
        public string Id = Guid.NewGuid().ToString();
        public string Mode = "Base";
        public string Label = "";
        public bool Enabled = true;
        public InputRef Input = new InputRef();
        public string Action = "Virtual button";
        public int VJoy = 1;
        public int Target;
        public double Deadzone = 0.03;
        public double Saturation = 1;
        public double Curve = 0;
        public bool Invert;
        public bool Unipolar;
        public bool Toggle;
        public double RangeMin = .5;
        public double RangeMax = 1;
        public string Keys = "Space";
        public string Macro = "Ctrl+G\nWAIT 200\nG";
        public int Repeat = 1;
        public string SwitchMode = "Base";
        public InputRef Second;
        public string Merge = "Average";
        public InputRef Condition;
        public override string ToString() {
            string destination = Action;
            if (Action == "Virtual axis") destination = "vJoy " + VJoy + " / " + InputRef.AxisNames[Target];
            if (Action == "Virtual button") destination = "vJoy " + VJoy + " / Button " + (Target + 1);
            if (Action == "Virtual hat") destination = "vJoy " + VJoy + " / Hat " + (Target + 1);
            if (Action == "Keyboard") destination = Keys;
            if (Action == "Switch mode") destination = "Mode: " + SwitchMode;
            if (Action == "Mouse button") destination = new[] { "Left click", "Right click", "Middle click" }[Target];
            string range=Input.Kind=="Axis" && Action!="Virtual axis" ? " ["+RangeMin.ToString("0.00")+" to "+RangeMax.ToString("0.00")+"]" : "";
            return Input + "  →  " + destination + range + (String.IsNullOrWhiteSpace(Label) ? "" : "   ·   " + Label);
        }
    }
    public class Profile {
        public int Version = 1;
        public string Name = "Untitled profile";
        [XmlIgnore] public List<string> Modes = new List<string> { "Base", "Flight" };
        [XmlArray("Modes"), XmlArrayItem("string")] public string[] ModeNames {
            get { return Modes.ToArray(); }
            set { Modes = value == null ? new List<string>() : value.ToList(); }
        }
        public List<Mapping> Mappings = new List<Mapping>();
        public List<ControlLabel> ControlLabels = new List<ControlLabel>();
        public void NameControl(InputRef input,string name) {
            name=(name??"").Trim();ControlLabels.RemoveAll(x=>x.Key==input.Key);
            if(name.Length>0)ControlLabels.Add(new ControlLabel{Key=input.Key,Name=name});
            foreach(var m in Mappings)foreach(var i in new[]{m.Input,m.Second,m.Condition}.Where(x=>x!=null&&x.Key==input.Key))i.Alias=name;
            input.Alias=name;
        }
        public void ApplyControlLabels(IEnumerable<InputRef> inputs) {
            foreach(var input in inputs){
                var label=ControlLabels.FirstOrDefault(x=>x.Key==input.Key);input.Alias=label==null?"":label.Name;
                foreach(var m in Mappings)foreach(var reference in new[]{m.Input,m.Second,m.Condition}.Where(x=>x!=null&&x.Key==input.Key))reference.DefaultName=input.DefaultName;
            }
        }
        public List<Mapping> Effective(string mode) {
            return Visible(mode).Where(x=>x.Enabled).ToList();
        }
        public List<Mapping> Visible(string mode) {
            var local=Mappings.Where(x=>x.Mode==mode).ToList();
            if(mode=="Base")return local;
            var overridden=new HashSet<string>(local.Select(x=>x.Input.Key));
            return Mappings.Where(x=>x.Mode=="Base"&&!overridden.Contains(x.Input.Key)).Concat(local).ToList();
        }
        public void UpsertAction(Mapping action,string inheritedId) {
            // A mode overrides the whole input. Copy its inherited siblings on
            // the first edit so changing one action never drops the others.
            if(action.Mode!="Base" && !Mappings.Any(x=>x.Mode==action.Mode&&x.Input.Key==action.Input.Key)) {
                var siblings=new Profile{Mappings=Mappings.Where(x=>x.Mode=="Base"&&x.Input.Key==action.Input.Key&&x.Id!=inheritedId).ToList()}.Clone().Mappings;
                foreach(var sibling in siblings){sibling.Id=Guid.NewGuid().ToString();sibling.Mode=action.Mode;Mappings.Add(sibling);}
            }
            int index=Mappings.FindIndex(x=>x.Id==action.Id);
            if(index>=0)Mappings[index]=action;else Mappings.Add(action);
        }
        public void Validate() {
            if (Version != 1) throw new InvalidDataException("This profile version is not supported.");
            if (Modes == null || Modes.Count == 0 || Modes.Count > 64 || !Modes.Contains("Base") || Modes.Any(String.IsNullOrWhiteSpace) || Modes.Distinct().Count() != Modes.Count)
                throw new InvalidDataException("The profile has invalid mode names.");
            if (Mappings == null || Mappings.Count > 4096) throw new InvalidDataException("The profile has too many mappings.");
            if(ControlLabels==null||ControlLabels.Count>4096||ControlLabels.Any(x=>x==null||String.IsNullOrWhiteSpace(x.Key)||String.IsNullOrWhiteSpace(x.Name)||x.Name.Length>64)||ControlLabels.Select(x=>x.Key).Distinct().Count()!=ControlLabels.Count)throw new InvalidDataException("Invalid control labels.");
            var ids = new HashSet<string>();
            foreach (var m in Mappings) {
                if (m == null || !ids.Add(m.Id) || !Modes.Contains(m.Mode)) throw new InvalidDataException("Invalid or duplicate mapping.");
                ValidateInput(m.Input);
                if (m.VJoy < 1 || m.VJoy > 16 || m.Target < 0) throw new InvalidDataException("Invalid output number.");
                if (!Finite(m.Deadzone) || !Finite(m.Saturation) || !Finite(m.Curve) || m.Deadzone < 0 || m.Deadzone > .5 || m.Saturation <= m.Deadzone || m.Saturation > 1 || m.Curve < -1 || m.Curve > 1)
                    throw new InvalidDataException("Invalid curve or dead zone.");
                if (!Finite(m.RangeMin) || !Finite(m.RangeMax) || m.RangeMin < -1 || m.RangeMax > 1 || m.RangeMin >= m.RangeMax) throw new InvalidDataException("The active axis range must increase from -1 to +1.");
                if (m.Second != null) { ValidateInput(m.Second); if (m.Second.Kind != "Axis" || m.Input.Kind != "Axis") throw new InvalidDataException("Merging requires two axes."); }
                if (!new[] { "Average", "Difference", "Maximum", "Minimum" }.Contains(m.Merge)) throw new InvalidDataException("Invalid merge operation.");
                if (m.Condition != null) { ValidateInput(m.Condition); if (m.Condition.Kind == "Axis" || (m.Condition.Kind == "Hat" && m.Condition.Direction < 0)) throw new InvalidDataException("A condition must be a button or a hat direction."); }
                if (m.Action == "Virtual axis") { if (m.Input.Kind != "Axis" || m.Target > 7) throw new InvalidDataException("Invalid axis mapping."); }
                else if (m.Action == "Virtual hat") { if (m.Input.Kind != "Hat" || m.Input.Direction != -1 || m.Target > 3) throw new InvalidDataException("Invalid hat mapping."); }
                else {
                    if (m.Input.Kind == "Hat" && m.Input.Direction < 0) throw new InvalidDataException("This action requires an axis range, button, or hat direction.");
                    if (m.Action == "Virtual button") { if (m.Target > 127) throw new InvalidDataException("Button must be 1–128."); }
                    else if (m.Action == "Keyboard") KeyNames.Parse(m.Keys);
                    else if (m.Action == "Macro") { MacroStep.Parse(m.Macro); if (m.Repeat < 1 || m.Repeat > 20) throw new InvalidDataException("Repeat must be 1–20."); }
                    else if (m.Action == "Switch mode") { if (!Modes.Contains(m.SwitchMode)) throw new InvalidDataException("The destination mode does not exist."); }
                    else if (m.Action == "Mouse button") { if (m.Target > 2) throw new InvalidDataException("Invalid mouse button."); }
                    else throw new InvalidDataException("Unknown action: " + m.Action);
                }
            }
        }
        static bool Finite(double x) { return !Double.IsNaN(x) && !Double.IsInfinity(x); }
        static void ValidateInput(InputRef i) {
            Guid g;
            if (i == null || !Guid.TryParse(i.Device, out g) || i.Index < 0 ||
                (i.Kind == "Axis" && (i.Index > 7 || i.Direction != -1)) ||
                (i.Kind == "Button" && (i.Index > 127 || i.Direction != -1)) ||
                (i.Kind == "Hat" && (i.Index > 3 || i.Direction < -1 || i.Direction > 7)) ||
                !new[] { "Axis", "Button", "Hat" }.Contains(i.Kind)) throw new InvalidDataException("Invalid source input.");
        }
        public void Save(string path) {
            Validate();
            var temp = path + ".tmp";
            try {
                using (var s = new FileStream(temp, FileMode.Create, FileAccess.Write)) {
                    new XmlSerializer(typeof(Profile)).Serialize(s, this); s.Flush(true);
                }
                if (File.Exists(path)) File.Replace(temp, path, path + ".bak"); else File.Move(temp, path);
            } finally { if (File.Exists(temp)) File.Delete(temp); }
        }
        public static Profile Load(string path) {
            if (new FileInfo(path).Length > 4 * 1024 * 1024) throw new InvalidDataException("Profile is too large.");
            using (var r = XmlReader.Create(path, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null })) {
                var p = (Profile)new XmlSerializer(typeof(Profile)).Deserialize(r); p.Validate(); return p;
            }
        }
        public Profile Clone() {
            var ser = new XmlSerializer(typeof(Profile));
            using (var s = new MemoryStream()) { ser.Serialize(s, this); s.Position = 0; return (Profile)ser.Deserialize(s); }
        }
    }
    public static class AxisMath {
        public static double Apply(double value, Mapping m) {
            double x = Math.Max(-1, Math.Min(1, value));
            if (m.Unipolar) {
                x = (x + 1) / 2;
                if (m.Invert) x = 1 - x;
                x = Math.Max(0, Math.Min(1, (x - m.Deadzone) / (m.Saturation - m.Deadzone)));
                return 2 * Math.Pow(x, Math.Pow(3, m.Curve)) - 1;
            }
            if (m.Invert) x = -x;
            return Math.Sign(x) * Math.Pow(Math.Max(0, Math.Min(1, (Math.Abs(x) - m.Deadzone) / (m.Saturation - m.Deadzone))), Math.Pow(3, m.Curve));
        }
        public static double Combine(double a, double b, string method) {
            if (method == "Difference") return (a - b) / 2;
            if (method == "Maximum") return Math.Max(a, b);
            if (method == "Minimum") return Math.Min(a, b);
            return (a + b) / 2;
        }
    }
    public static class KeyNames {
        static readonly Dictionary<string,int> Special = new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase) {
            {"Ctrl",0xA2},{"Control",0xA2},{"LCtrl",0xA2},{"RCtrl",0xA3},{"Shift",0xA0},{"LShift",0xA0},{"RShift",0xA1},
            {"Alt",0xA4},{"LAlt",0xA4},{"RAlt",0xA5},{"Space",32},{"Enter",13},{"Escape",27},{"Esc",27},{"Tab",9},
            {"Backspace",8},{"Delete",46},{"Insert",45},{"Home",36},{"End",35},{"PageUp",33},{"PageDown",34},
            {"Left",37},{"Up",38},{"Right",39},{"Down",40},{"CapsLock",20},{"NumLock",144},{"ScrollLock",145},
            {"Minus",189},{"Plus",187},{"Comma",188},{"Period",190},{"Slash",191},{"Backslash",220},
            {"Semicolon",186},{"Quote",222},{"LeftBracket",219},{"RightBracket",221},{"Grave",192},
            {"Multiply",106},{"Add",107},{"Subtract",109},{"Decimal",110},{"Divide",111}
        };
        public static int[] Parse(string chord) {
            if (String.IsNullOrWhiteSpace(chord)) throw new InvalidDataException("Enter a key or chord, such as Space or Ctrl+G.");
            var keys = new List<int>();
            foreach (var raw in chord.Split('+')) {
                string s = raw.Trim(); int key, n;
                if (s.Length == 1 && Char.IsLetterOrDigit(s[0]) && s[0] < 128) key = Char.ToUpperInvariant(s[0]);
                else if (Special.TryGetValue(s, out key)) { }
                else if (s.StartsWith("F",StringComparison.OrdinalIgnoreCase) && Int32.TryParse(s.Substring(1),out n) && n >= 1 && n <= 24) key = 111 + n;
                else if (s.StartsWith("Num",StringComparison.OrdinalIgnoreCase) && Int32.TryParse(s.Substring(3),out n) && n >= 0 && n <= 9) key = 96 + n;
                else throw new InvalidDataException("Unknown key: " + s + ". Use names like Ctrl, Space, F1, Num0, Plus, or Left.");
                if (!keys.Contains(key)) keys.Add(key);
            }
            if (keys.Count > 8) throw new InvalidDataException("A chord can contain up to 8 keys.");
            if (keys.Contains(123) && (keys.Contains(162) || keys.Contains(163)) && (keys.Contains(164) || keys.Contains(165))) throw new InvalidDataException("Ctrl+Alt+F12 is reserved for Stop.");
            return keys.ToArray();
        }
    }
    public class MacroStep {
        public int[] Keys = new int[0]; public int Duration;
        public static List<MacroStep> Parse(string script) {
            if (String.IsNullOrWhiteSpace(script) || script.Length > 16384) throw new InvalidDataException("Enter at least one macro step (up to 16 KB).");
            var steps = new List<MacroStep>();
            foreach (var raw in script.Split('\n')) {
                var line = raw.Trim(); if (line.Length == 0 || line.StartsWith("#")) continue;
                if (line.StartsWith("WAIT ",StringComparison.OrdinalIgnoreCase)) {
                    int n; if (!Int32.TryParse(line.Substring(5).Trim(),out n) || n < 1 || n > 60000) throw new InvalidDataException("WAIT needs a delay from 1 to 60000 milliseconds.");
                    steps.Add(new MacroStep { Duration = n });
                } else { steps.Add(new MacroStep { Keys = KeyNames.Parse(line), Duration = 60 }); steps.Add(new MacroStep { Duration = 60 }); }
            }
            if (steps.Count == 0 || steps.Count > 512) throw new InvalidDataException("Macro needs 1–256 key presses or waits.");
            return steps;
        }
    }
}
