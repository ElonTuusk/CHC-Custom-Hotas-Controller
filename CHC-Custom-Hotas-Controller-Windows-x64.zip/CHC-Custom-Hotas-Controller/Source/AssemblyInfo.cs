using System.Reflection;
[assembly: AssemblyTitle("CHC Custom Hotas Controller")]
[assembly: AssemblyProduct("CHC Custom Hotas Controller")]
[assembly: AssemblyDescription("A simpler Windows joystick and HOTAS mapper")]
[assembly: AssemblyVersion("0.4.0.0")]
[assembly: AssemblyFileVersion("0.4.0.0")]
