using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using SharpDX.DirectInput;

namespace StickShift {
    public class DeviceSample {
        public double[] Axes = new double[8];
        public bool[] Buttons = new bool[128];
        public int[] Hats = new[] { -1, -1, -1, -1 };
        public bool Connected;
        public double Value(InputRef i) {
            if (i.Kind == "Axis") return Axes[i.Index];
            if (i.Kind == "Button") return Buttons[i.Index] ? 1 : 0;
            int a = Hats[i.Index];
            return i.Direction < 0 ? a : (a >= 0 && ((a + 2250) / 4500) % 8 == i.Direction ? 1 : 0);
        }
    }
    public class InputDevice : IDisposable {
        public string Id, Name;
        public List<InputRef> Inputs = new List<InputRef>();
        Joystick joystick;
        public InputDevice(DirectInput root, DeviceInstance info, IntPtr window) {
            Id = info.InstanceGuid.ToString(); Name = info.InstanceName.Trim();
            joystick = new Joystick(root, info.InstanceGuid);
            try {
                joystick.SetCooperativeLevel(window, CooperativeLevel.Background | CooperativeLevel.NonExclusive);
                joystick.Properties.AxisMode = DeviceAxisMode.Absolute;
                var objects=new List<NativeFormat.ObjectFormat>();
                int index=0;
                foreach (var o in joystick.GetObjects(DeviceObjectTypeFlags.Axis).OrderBy(x=>x.ObjectId.InstanceNumber).Take(8)) {
                    joystick.GetObjectPropertiesById(o.ObjectId).Range = new InputRange(-32768,32767);
                    var input=Ref("Axis",index,-1);input.Name=o.Name;Inputs.Add(input);
                    objects.Add(NativeFormat.For(o,index*4));index++;
                }
                index=0;
                foreach(var o in joystick.GetObjects(DeviceObjectTypeFlags.Button).OrderBy(x=>x.ObjectId.InstanceNumber).Take(128)) {
                    Inputs.Add(Ref("Button",index,-1));objects.Add(NativeFormat.For(o,48+index));index++;
                }
                index=0;
                foreach(var o in joystick.GetObjects(DeviceObjectTypeFlags.PointOfViewController).OrderBy(x=>x.ObjectId.InstanceNumber).Take(4)) {
                    Inputs.Add(Ref("Hat",index,-1));for(int d=0;d<8;d++)Inputs.Add(Ref("Hat",index,d));
                    objects.Add(NativeFormat.For(o,32+index*4));index++;
                }
                NativeFormat.Apply(joystick.NativePointer,objects);
                joystick.Acquire();
            } catch { joystick.Dispose(); throw; }
        }
        InputRef Ref(string kind,int index,int direction) { return new InputRef { Device=Id,DeviceName=Name,Kind=kind,Index=index,Direction=direction }; }
        public DeviceSample Read() {
            try { joystick.Poll(); return Convert(joystick.GetCurrentState()); }
            catch {
                try { joystick.Acquire(); joystick.Poll(); return Convert(joystick.GetCurrentState()); }
                catch { return new DeviceSample(); }
            }
        }
        DeviceSample Convert(JoystickState state) {
            int[] a = {state.X,state.Y,state.Z,state.RotationX,state.RotationY,state.RotationZ,state.Sliders[0],state.Sliders[1]};
            // DirectInput writes only the objects in the requested format. Do not
            // expose undefined stack bytes from unsupported buttons, hats or axes.
            var sample=new DeviceSample{Connected=true};
            foreach(var i in Inputs) {
                if(i.Kind=="Axis")sample.Axes[i.Index]=Math.Max(-1,Math.Min(1,(a[i.Index]+32768)/32767.5-1));
                else if(i.Kind=="Button")sample.Buttons[i.Index]=state.Buttons[i.Index];
                else if(i.Direction<0)sample.Hats[i.Index]=state.PointOfViewControllers[i.Index];
            }
            return sample;
        }
        public void Dispose() { try { joystick.Unacquire(); } finally { joystick.Dispose(); } }
        public override string ToString() { return Name; }
    }
    // Bind each physical object by instance, rather than by axis GUID. Some RC
    // controllers expose two different channels using the same axis GUID.
    static class NativeFormat {
        [StructLayout(LayoutKind.Sequential)] public struct ObjectFormat { public IntPtr Guid; public uint Offset,Type,Flags; }
        [StructLayout(LayoutKind.Sequential)] struct DataFormat { public uint Size,ObjectSize,Flags,DataSize,Count;public IntPtr Objects; }
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int SetFormat(IntPtr self,ref DataFormat format);
        public static ObjectFormat For(DeviceObjectInstance o,int offset) { return new ObjectFormat{Offset=(uint)offset,Type=((uint)o.ObjectId.Flags&0xffu)|((uint)o.ObjectId.InstanceNumber<<8)}; }
        public static void Apply(IntPtr device,List<ObjectFormat> objects) {
            int size=Marshal.SizeOf(typeof(ObjectFormat));IntPtr buffer=Marshal.AllocHGlobal(size*objects.Count);
            try {
                for(int i=0;i<objects.Count;i++)Marshal.StructureToPtr(objects[i],IntPtr.Add(buffer,size*i),false);
                var format=new DataFormat{Size=(uint)Marshal.SizeOf(typeof(DataFormat)),ObjectSize=(uint)size,Flags=1,DataSize=272,Count=(uint)objects.Count,Objects=buffer};
                var table=Marshal.ReadIntPtr(device);var call=(SetFormat)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(table,11*IntPtr.Size),typeof(SetFormat));
                int result=call(device,ref format);if(result<0)Marshal.ThrowExceptionForHR(result);
            } finally { Marshal.FreeHGlobal(buffer); }
        }
    }
    public class DeviceHub : IDisposable {
        DirectInput root = new DirectInput();
        public List<InputDevice> Devices = new List<InputDevice>();
        public List<string> Errors = new List<string>();
        public void Scan(IntPtr window) {
            foreach(var d in Devices) d.Dispose(); Devices.Clear(); Errors.Clear();
            foreach(var info in root.GetDevices(DeviceClass.GameControl,DeviceEnumerationFlags.AttachedOnly)) {
                // vJoy's product/vendor pair is 0xBEAD / 0x1234; never feed virtual inputs back into themselves.
                if (info.ProductGuid.ToString().StartsWith("bead1234",StringComparison.OrdinalIgnoreCase) || info.InstanceName.IndexOf("vJoy",StringComparison.OrdinalIgnoreCase)>=0) continue;
                try { Devices.Add(new InputDevice(root,info,window)); }
                catch(Exception e) { Errors.Add(info.InstanceName + ": " + e.Message); }
            }
        }
        public Dictionary<string,DeviceSample> Read() { return Devices.ToDictionary(x=>x.Id,x=>x.Read()); }
        public bool Supports(InputRef i) { return Devices.Any(d=>d.Id==i.Device && d.Inputs.Any(x=>x.Key==i.Key)); }
        public void Dispose() { foreach(var d in Devices) d.Dispose(); root.Dispose(); }
    }
    public class VirtualOutput {
        [DllImport("kernel32",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr LoadLibraryEx(string file,IntPtr reserved,uint flags);
        [DllImport("kernel32",CharSet=CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr lib,string name);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool EnabledFn();
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int StatusFn(uint id);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool DeviceFn(uint id);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void ReleaseFn(uint id);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool AxisExistsFn(uint id,uint axis);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool AxisRangeFn(uint id,uint axis,out int value);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int CountFn(uint id);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool AxisFn(int value,uint id,uint axis);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool ButtonFn(bool value,uint id,byte button);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate bool HatFn(int value,uint id,byte hat);
        EnabledFn enabled; StatusFn status; DeviceFn acquire,reset; ReleaseFn release;
        AxisExistsFn exists; AxisRangeFn min,max; CountFn buttons,hats; AxisFn axis; ButtonFn button; HatFn hat;
        public string Information = "vJoy is not installed.";
        public bool Available;
        readonly HashSet<int> owned = new HashSet<int>();
        readonly Dictionary<string,Tuple<int,int>> ranges = new Dictionary<string,Tuple<int,int>>();
        IntPtr library;
        T Bind<T>(string name) where T:class {
            var p=GetProcAddress(library,name); if(p==IntPtr.Zero) throw new InvalidOperationException("vJoy library is missing " + name);
            return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
        }
        public VirtualOutput() {
            try {
                string file = new[] {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"vJoy","x64","vJoyInterface.dll"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"vJoy","x64","vJoyInterface.dll")
                }.FirstOrDefault(File.Exists);
                if(file==null) return;
                library=LoadLibraryEx(file,IntPtr.Zero,0x1100);
                if(library==IntPtr.Zero) throw new InvalidOperationException("Cannot load vJoy (Windows error " + Marshal.GetLastWin32Error()+").");
                enabled=Bind<EnabledFn>("vJoyEnabled");status=Bind<StatusFn>("GetVJDStatus");acquire=Bind<DeviceFn>("AcquireVJD");reset=Bind<DeviceFn>("ResetVJD");release=Bind<ReleaseFn>("RelinquishVJD");
                exists=Bind<AxisExistsFn>("GetVJDAxisExist");min=Bind<AxisRangeFn>("GetVJDAxisMin");max=Bind<AxisRangeFn>("GetVJDAxisMax");
                buttons=Bind<CountFn>("GetVJDButtonNumber");hats=Bind<CountFn>("GetVJDContPovNumber");
                axis=Bind<AxisFn>("SetAxis");button=Bind<ButtonFn>("SetBtn");hat=Bind<HatFn>("SetContPov");
                Available=enabled(); Information=Available ? "vJoy driver ready" : "vJoy is installed, but its driver is not enabled.";
            } catch(Exception e) { Information=e.Message; }
        }
        public string Describe() {
            if(!Available) return Information;
            var lines = new List<string>{Information};
            for(uint id=1;id<=16;id++) {
                int s=status(id);if(s==3) continue;
                lines.Add("Device "+id+": "+(s==1?"available":s==0?"owned by this app":s==2?"in use by another app":"unknown")+"; "+buttons(id)+" buttons, "+hats(id)+" continuous hats");
            }
            return String.Join("\n",lines);
        }
        public void Start(List<Mapping> mappings) {
            var virtuals=mappings.Where(m=>m.Enabled && m.Action.StartsWith("Virtual")).ToList();
            if(virtuals.Count==0) return;
            if(!Available) throw new InvalidOperationException(Information+" Open vJoy Configuration and enable a virtual device.");
            try {
                foreach(int id in virtuals.Select(x=>x.VJoy).Distinct()) {
                    int s=status((uint)id);
                    if(s!=1) throw new InvalidOperationException("vJoy "+id+" is "+(s==0||s==2?"already in use. Stop Gremlin or another mapper first.":"not configured. Add it in vJoy Configuration."));
                    if(!acquire((uint)id)) throw new InvalidOperationException("Could not acquire vJoy "+id);
                    owned.Add(id);
                    for(int a=0;a<8;a++) if(exists((uint)id,(uint)(0x30+a))) {
                        int lo,hi;if(!min((uint)id,(uint)(0x30+a),out lo)||!max((uint)id,(uint)(0x30+a),out hi)||hi<=lo) throw new InvalidOperationException("Cannot read vJoy axis range.");
                        ranges[id+"/"+a]=Tuple.Create(lo,hi);
                    }
                }
                foreach(var m in virtuals) {
                    if(m.Action=="Virtual axis" && !ranges.ContainsKey(m.VJoy+"/"+m.Target)) throw new InvalidOperationException("Enable "+InputRef.AxisNames[m.Target]+" on vJoy "+m.VJoy+" in vJoy Configuration.");
                    if(m.Action=="Virtual button" && buttons((uint)m.VJoy)<=m.Target) throw new InvalidOperationException("vJoy "+m.VJoy+" does not have button "+(m.Target+1));
                    if(m.Action=="Virtual hat" && hats((uint)m.VJoy)<=m.Target) throw new InvalidOperationException("Enable continuous hat "+(m.Target+1)+" on vJoy "+m.VJoy+".");
                }
                Neutral();
            } catch { Stop();throw; }
        }
        public void Axis(int id,int target,double value) {
            var r=ranges[id+"/"+target];
            if(!axis((int)Math.Round(r.Item1+(Math.Max(-1,Math.Min(1,value))+1)*.5*(r.Item2-r.Item1)),(uint)id,(uint)(0x30+target))) throw new IOException("vJoy axis output failed.");
        }
        public void Button(int id,int target,bool pressed) { if(!button(pressed,(uint)id,(byte)(target+1))) throw new IOException("vJoy button output failed."); }
        public void Hat(int id,int target,int angle) { if(!hat(angle,(uint)id,(byte)(target+1))) throw new IOException("vJoy hat output failed."); }
        public void Neutral() { foreach(int id in owned) if(!reset((uint)id)) throw new IOException("Could not reset vJoy "+id); }
        public void Stop() {
            foreach(int id in owned) { try { reset((uint)id); } finally { release((uint)id); } }
            owned.Clear();ranges.Clear();
        }
    }
    public class SystemOutput {
        [StructLayout(LayoutKind.Sequential)] struct MouseInput { public int dx,dy; public uint mouseData,flags,time; public UIntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] struct KeyboardInput { public ushort key,scan; public uint flags,time; public UIntPtr extra; }
        [StructLayout(LayoutKind.Explicit)] struct Union { [FieldOffset(0)] public MouseInput mouse; [FieldOffset(0)] public KeyboardInput keyboard; }
        [StructLayout(LayoutKind.Sequential)] struct Input { public uint type; public Union data; }
        [DllImport("user32",SetLastError=true)] static extern uint SendInput(uint count,Input[] inputs,int size);
        [DllImport("user32")] static extern uint MapVirtualKey(uint code,uint type);
        HashSet<int> held = new HashSet<int>();
        static void Emit(int code,bool down) {
            Input i = new Input();
            if(code<0) { i.type=0; i.data.mouse.flags = code==-1?(down?2u:4u):code==-2?(down?8u:16u):(down?32u:64u); }
            else {
                uint scan=MapVirtualKey((uint)code,4);
                bool ext=(scan&0xff00)!=0 || code==0xA3 || code==0xA5 || (code>=33 && code<=46) || code==111 || code==144;
                i.type=1;i.data.keyboard.scan=(ushort)(scan&0xff);i.data.keyboard.flags=8u|(down?0u:2u)|(ext?1u:0u);
                if(scan==0) { i.data.keyboard.key=(ushort)code;i.data.keyboard.flags=down?0u:2u; }
            }
            if(SendInput(1,new[]{i},Marshal.SizeOf(typeof(Input)))!=1) throw new IOException("Windows blocked a keyboard or mouse output. Run the app at the same permission level as the game.");
        }
        public void Set(HashSet<int> desired) {
            foreach(int k in held.Except(desired).OrderBy(x=>IsModifier(x)?1:0).ToArray()) { Emit(k,false);held.Remove(k); }
            foreach(int k in desired.Except(held).OrderBy(x=>IsModifier(x)?0:1).ToArray()) { Emit(k,true);held.Add(k); }
        }
        static bool IsModifier(int key) { return key>=160 && key<=165; }
        public void Release() {
            foreach(int k in held.OrderBy(x=>IsModifier(x)?1:0).ToArray()) { try { Emit(k,false);held.Remove(k); } catch { /* Retain failed releases for the next cleanup attempt. */ } }
        }
    }
}
