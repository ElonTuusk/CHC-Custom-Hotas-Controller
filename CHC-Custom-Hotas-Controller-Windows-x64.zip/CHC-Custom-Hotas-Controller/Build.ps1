param([string]$OutputName = 'CHC.exe')
$ErrorActionPreference = 'Stop'
$appRoot = $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$wpf = Join-Path $framework 'WPF'
$arguments = @('/nologo','/target:winexe','/platform:x64','/optimize+',('/win32icon:' + (Join-Path $appRoot 'Assets\CHC.ico')),('/out:' + (Join-Path $appRoot $OutputName)))
foreach ($assembly in @('System.dll','System.Core.dll','System.Xml.dll','System.Xaml.dll')) { $arguments += '/r:' + (Join-Path $framework $assembly) }
foreach ($assembly in @('PresentationCore.dll','PresentationFramework.dll','WindowsBase.dll')) { $arguments += '/r:' + (Join-Path $wpf $assembly) }
foreach ($assembly in @('SharpDX.dll','SharpDX.DirectInput.dll')) { $arguments += '/r:' + (Join-Path $appRoot $assembly) }
$arguments += (Get-ChildItem (Join-Path $appRoot 'Source') -Filter '*.cs').FullName
& (Join-Path $framework 'csc.exe') $arguments
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
Write-Output ('Built ' + $OutputName)

